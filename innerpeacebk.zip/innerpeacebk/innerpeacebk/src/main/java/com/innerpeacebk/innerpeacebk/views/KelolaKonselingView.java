package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.Konsultasi;
import com.innerpeacebk.innerpeacebk.repository.KonsultasiRepository;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;

@RolesAllowed("GURU_BK") // Sesuaikan role security Anda untuk Guru BK
@Route(value = "konsultasi") // Sesuai dengan URL yang dituju di navbar
public class KelolaKonselingView extends VerticalLayout {

    public KelolaKonselingView(KonsultasiRepository konsultasiRepository) {
        setSpacing(true);
        setPadding(true);

        add(new H2("Kelola Data Konsultasi Siswa"));

        // Membuat Grid / Tabel untuk menampilkan data konsultasi
        Grid<Konsultasi> grid = new Grid<>(Konsultasi.class, false);
        grid.addColumn(Konsultasi::getKode).setHeader("Kode");
        grid.addColumn(Konsultasi::getNis).setHeader("NIS");
        grid.addColumn(Konsultasi::getKategori).setHeader("Kategori");
        grid.addColumn(Konsultasi::getTopik).setHeader("Topik");
        grid.addColumn(Konsultasi::getMetode).setHeader("Metode");
        grid.addColumn(Konsultasi::getStatus).setHeader("Status");

        // Ambil data dari database
        grid.setItems(konsultasiRepository.findAll());

        add(grid);
    }
}