package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "laporan_kasus")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LaporanKasus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String judul;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String deskripsi;

    private String lokasi;

    @Column(name = "tanggal_kejadian")
    private LocalDateTime tanggalKejadian;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusKasus status = StatusKasus.PENDING;

    @Column(name = "catatan_gurubk", columnDefinition = "TEXT")
    private String catatanGuruBK;

    @ManyToOne
    @JoinColumn(name = "pelapor_id")
    private User pelapor;

    @ManyToOne
    @JoinColumn(name = "guru_bk_id")
    private User penanggungJawab;

    @Column(name = "tanggal_dibuat")
    private LocalDateTime tanggalDibuat = LocalDateTime.now();
}