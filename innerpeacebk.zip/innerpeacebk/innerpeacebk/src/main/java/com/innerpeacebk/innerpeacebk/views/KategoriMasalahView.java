package com.innerpeacebk.innerpeacebk.views;

import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;

import java.util.ArrayList;
import java.util.List;

@Route(value = "kategori-masalah", layout = MainLayout.class)
@PageTitle("Kategori Masalah | InnerPeaceBK")
@PermitAll
@RolesAllowed("GURU")
public class KategoriMasalahView extends VerticalLayout {

    // DTO Model Kategori
    public static class KategoriModel {
        private String nama;
        private int jumlah;
        private double persentase; // Value 0.0 - 1.0 untuk ProgressBar
        private String badgeBgColor;
        private String badgeTextColor;

        public KategoriModel(String nama, int jumlah, double persentase, String badgeBgColor, String badgeTextColor) {
            this.nama = nama;
            this.jumlah = jumlah;
            this.persentase = persentase;
            this.badgeBgColor = badgeBgColor;
            this.badgeTextColor = badgeTextColor;
        }

        public String getNama() { return nama; }
        public int getJumlah() { return jumlah; }
        public double getPersentase() { return persentase; }
        public String getBadgeBgColor() { return badgeBgColor; }
        public String getBadgeTextColor() { return badgeTextColor; }
    }

    public KategoriMasalahView() {
        setSizeFull();
        setPadding(true);
        setSpacing(true);
        getStyle().set("background-color", "#f8fafc");

        // 1. Header Section
        add(createHeaderSection());

        // 2. Grid Cards Section (Layout 2 Kolom)
        add(createCategoryGrid());
    }

    private VerticalLayout createHeaderSection() {
        VerticalLayout headerLayout = new VerticalLayout();
        headerLayout.setPadding(false);
        headerLayout.setSpacing(false);

        H2 title = new H2("Kategori Masalah");
        title.getStyle()
                .set("margin", "0")
                .set("font-size", "24px")
                .set("font-weight", "800")
                .set("color", "#0f172a");

        Paragraph subtitle = new Paragraph("Daftar kategori permasalahan dalam sistem InnerPeaceBK.");
        subtitle.getStyle()
                .set("margin", "4px 0 0 0")
                .set("color", "#64748b")
                .set("font-size", "14px");

        headerLayout.add(title, subtitle);
        return headerLayout;
    }

    private VerticalLayout createCategoryGrid() {
        VerticalLayout container = new VerticalLayout();
        container.setPadding(false);
        container.setSpacing(true);
        container.setMaxWidth("1000px"); // Menjaga lebar kartu agar rapi seperti di UI

        List<KategoriModel> data = getKategoriData();

        // Bagi data ke dalam baris 2 kolom
        for (int i = 0; i < data.size(); i += 2) {
            HorizontalLayout row = new HorizontalLayout();
            row.setWidthFull();
            row.setSpacing(true);

            // Kolom Kiri
            VerticalLayout card1 = createCategoryCard(data.get(i));
            row.add(card1);

            // Kolom Kanan (jika ada)
            if (i + 1 < data.size()) {
                VerticalLayout card2 = createCategoryCard(data.get(i + 1));
                row.add(card2);
            } else {
                // Spacer kosong untuk baris ganjil (seperti kartu 'Lainnya')
                VerticalLayout emptyCard = new VerticalLayout();
                emptyCard.setWidthFull();
                row.add(emptyCard);
            }

            container.add(row);
        }

        return container;
    }

    private VerticalLayout createCategoryCard(KategoriModel item) {
        VerticalLayout card = new VerticalLayout();
        card.setWidthFull();
        card.setPadding(true);
        card.getStyle()
                .set("background-color", "#ffffff")
                .set("border-radius", "16px")
                .set("border", "1px solid #f1f5f9")
                .set("box-shadow", "0 1px 3px rgba(0,0,0,0.02)");

        HorizontalLayout content = new HorizontalLayout();
        content.setWidthFull();
        content.setAlignItems(FlexComponent.Alignment.CENTER);
        content.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);

        // 1. Badge Kategori (Kiri)
        Span badge = new Span(item.getNama());
        badge.getStyle()
                .set("background-color", item.getBadgeBgColor())
                .set("color", item.getBadgeTextColor())
                .set("padding", "8px 20px")
                .set("border-radius", "12px")
                .set("font-size", "14px")
                .set("font-weight", "700")
                .set("min-width", "110px")
                .set("text-align", "center");

        // 2. Progress Bar (Tengah)
        ProgressBar progressBar = new ProgressBar();
        progressBar.setValue(item.getPersentase());
        progressBar.setWidthFull();
        progressBar.getStyle()
                .set("height", "8px")
                .set("border-radius", "6px")
                .set("margin", "0 16px");

        // 3. Jumlah Kasus (Kanan)
        Span count = new Span(String.valueOf(item.getJumlah()));
        count.getStyle()
                .set("font-size", "16px")
                .set("font-weight", "800")
                .set("color", "#0f172a");

        content.add(badge, progressBar, count);
        card.add(content);

        return card;
    }

    // Data Dummy persis seperti di screenshot
    private List<KategoriModel> getKategoriData() {
        List<KategoriModel> list = new ArrayList<>();
        // Baris 1: Akademik & Bullying
        list.add(new KategoriModel("Akademik", 35, 0.85, "#dbeafe", "#2563eb"));
        list.add(new KategoriModel("Bullying", 8, 0.25, "#fee2e2", "#ef4444"));

        // Baris 2: Pertemanan & Keluarga
        list.add(new KategoriModel("Pertemanan", 22, 0.55, "#f3e8ff", "#9333ea"));
        list.add(new KategoriModel("Keluarga", 18, 0.45, "#ffedd5", "#ea580c"));

        // Baris 3: Mental & Karier
        list.add(new KategoriModel("Mental", 12, 0.30, "#fce7f3", "#ec4899"));
        list.add(new KategoriModel("Karier", 8, 0.25, "#dcfce7", "#16a34a"));

        // Baris 4: Lainnya
        list.add(new KategoriModel("Lainnya", 5, 0.15, "#f1f5f9", "#64748b"));

        return list;
    }
}