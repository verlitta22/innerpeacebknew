package com.innerpeacebk.innerpeacebk.entity;

public enum StatusKasus {
    PENDING,
    DIPROSES,
    SELESAI,
    DITOLAK
}