package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.Konsultasi;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface KonsultasiRepository extends JpaRepository<Konsultasi, Long> {

    // Cari berdasarkan NIS siswa
    List<Konsultasi> findByNis(String nis);

    // Hitung total konsultasi berdasarkan NIS siswa
    long countByNis(String nis);

    // Hitung berdasarkan NIS siswa dan Status
    long countByNisAndStatus(String nis, String status);

    // Ambil riwayat diurutkan berdasarkan ID terbesar (terbaru) untuk NIS tertentu
    List<Konsultasi> findByNisOrderByIdDesc(String nis);
}