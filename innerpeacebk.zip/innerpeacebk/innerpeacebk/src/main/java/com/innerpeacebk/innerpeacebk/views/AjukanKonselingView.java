package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.SesiKonseling;
import com.innerpeacebk.innerpeacebk.entity.StatusKonseling;
import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.SesiKonselingRepository;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.datetimepicker.DateTimePicker;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinSession;

import java.time.LocalDateTime;

@Route(value = "ajukan-konseling", layout = MainLayout.class)
@PageTitle("Ajukan Konseling - InnerPeaceBK")
public class AjukanKonselingView extends VerticalLayout implements BeforeEnterObserver {

    private final SesiKonselingRepository konselingRepository;

    private User currentUser;

    private final ComboBox<String> topikSelect = new ComboBox<>("Topik Konseling");
    private final DateTimePicker jadwalPicker = new DateTimePicker("Rencana Jadwal & Waktu Konseling");
    private final TextArea keluhanArea = new TextArea("Detail Keluhan / Permasalahan");

    private final Button simpanButton = new Button("Kirim Pengajuan", VaadinIcon.PAPERPLANE.create());
    private final Button batalButton = new Button("Batal", VaadinIcon.ARROW_LEFT.create());

    public AjukanKonselingView(SesiKonselingRepository konselingRepository) {
        this.konselingRepository = konselingRepository;

        setSizeFull();
        setAlignItems(FlexComponent.Alignment.CENTER);
        setJustifyContentMode(FlexComponent.JustifyContentMode.START);
        getStyle().set("padding", "24px").set("background-color", "#f8fafc");

        add(createFormCard());
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        // Cek apakah user sudah login
        currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        if (currentUser == null) {
            event.forwardTo("login");
        }
    }

    private Div createFormCard() {
        Div card = new Div();
        card.setMaxWidth("650px");
        card.setWidthFull();
        card.getStyle()
                .set("background-color", "#ffffff")
                .set("border-radius", "16px")
                .set("padding", "32px")
                .set("box-shadow", "0 10px 25px rgba(0,0,0,0.05)")
                .set("border", "1px solid #e2e8f0");

        VerticalLayout layout = new VerticalLayout();
        layout.setPadding(false);
        layout.setSpacing(true);
        layout.setAlignItems(FlexComponent.Alignment.STRETCH);

        // Header
        H2 title = new H2("Form Pengajuan Konseling");
        title.getStyle().set("margin", "0").set("color", "#1e293b").set("font-size", "22px");

        Paragraph subtitle = new Paragraph("Isi formulir di bawah ini untuk mengagendakan sesi bimbingan bersama Guru BK.");
        subtitle.getStyle().set("margin", "0 0 16px 0").set("color", "#64748b").set("font-size", "14px");

        // Pilihan Topik
        topikSelect.setItems(
                "Konsultasi Minat Kejuruan / Karir",
                "Masalah Belajar & Akademik",
                "Kendala Hubungan Sosial / Pertemanan",
                "Laporan Perundungan / Bullying",
                "Konsultasi Masalah Pribadi / Keluarga"
        );
        topikSelect.setPlaceholder("Pilih topik konseling...");
        topikSelect.setRequired(true);
        topikSelect.setWidthFull();

        // Pemilih Jadwal
        jadwalPicker.setMin(LocalDateTime.now());
        jadwalPicker.setValue(LocalDateTime.now().plusDays(1).withHour(9).withMinute(0));
        jadwalPicker.setRequiredIndicatorVisible(true);
        jadwalPicker.setWidthFull();

        // Input Keluhan
        keluhanArea.setPlaceholder("Ceritakan singkat permasalahan atau hal yang ingin kamu konsultasikan...");
        keluhanArea.setRequired(true);
        keluhanArea.setMinHeight("140px");
        keluhanArea.setWidthFull();

        // Tombol Aksi
        simpanButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        simpanButton.getStyle().set("background-color", "#2563eb").set("cursor", "pointer");
        simpanButton.addClickListener(e -> simpanPengajuan());

        batalButton.addClickListener(e -> UI.getCurrent().navigate("siswa-dashboard"));

        HorizontalLayout actions = new HorizontalLayout(batalButton, simpanButton);
        actions.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
        actions.setWidthFull();
        actions.getStyle().set("margin-top", "20px");

        layout.add(title, subtitle, topikSelect, jadwalPicker, keluhanArea, actions);
        card.add(layout);

        return card;
    }

    private void simpanPengajuan() {
        if (topikSelect.isEmpty() || jadwalPicker.getValue() == null || keluhanArea.isEmpty()) {
            Notification.show("Harap isi semua bidang form dengan benar!", 3000, Notification.Position.TOP_CENTER)
                    .addThemeVariants(NotificationVariant.LUMO_ERROR);
            return;
        }

        try {
            SesiKonseling konseling = new SesiKonseling();
            konseling.setTopik(topikSelect.getValue());
            konseling.setJadwalKonseling(jadwalPicker.getValue());
            konseling.setKeluhan(keluhanArea.getValue().trim());
            konseling.setSiswa(currentUser);
            konseling.setStatus(StatusKonseling.MENUNGGU_KONFIRMASI);

            konselingRepository.save(konseling);

            Notification.show("Pengajuan konseling berhasil dikirim!", 3000, Notification.Position.TOP_CENTER)
                    .addThemeVariants(NotificationVariant.LUMO_SUCCESS);

            UI.getCurrent().navigate("siswa-dashboard");

        } catch (Exception e) {
            Notification.show("Gagal menyimpan pengajuan: " + e.getMessage(), 3000, Notification.Position.TOP_CENTER)
                    .addThemeVariants(NotificationVariant.LUMO_ERROR);
        }
    }
}