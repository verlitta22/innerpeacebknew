package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "sesi_konseling")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SesiKonseling {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String topik;

    @Column(columnDefinition = "TEXT")
    private String keluhan;

    private LocalDateTime jadwalKonseling;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusKonseling status = StatusKonseling.MENUNGGU_KONFIRMASI;

    @ManyToOne
    @JoinColumn(name = "siswa_id", nullable = false)
    private User siswa;

    @ManyToOne
    @JoinColumn(name = "guru_bk_id")
    private User guruBk;

    private LocalDateTime tanggalPengajuan = LocalDateTime.now();
}