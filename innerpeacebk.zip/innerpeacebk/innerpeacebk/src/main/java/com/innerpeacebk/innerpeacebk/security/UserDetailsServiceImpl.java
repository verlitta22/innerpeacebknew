package com.innerpeacebk.innerpeacebk.security;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Karena findByUsername mengembalikan Optional<User>, gunakan .orElseThrow()
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User tidak ditemukan: " + username));

        // Mengambil role dari enum User.Role dan mengubahnya menjadi String untuk Spring Security
        // Pastikan method getRole() tersedia di Entity User Anda
        String roleName = user.getRole() != null ? user.getRole().name() : "GURU";

        List<GrantedAuthority> authorities = Collections.singletonList(
                new SimpleGrantedAuthority(roleName) 
        );

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(), // Sesuaikan dengan getter username di Entity Anda
                user.getPassword(), // Sesuaikan dengan getter password di Entity Anda
                authorities
        );
    }
}