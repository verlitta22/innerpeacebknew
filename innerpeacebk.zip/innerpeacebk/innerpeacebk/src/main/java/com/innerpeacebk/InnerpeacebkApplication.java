package com.innerpeacebk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InnerpeacebkApplication {

	public static void main(String[] args) {
		SpringApplication.run(InnerpeacebkApplication.class, args);
	}

}
