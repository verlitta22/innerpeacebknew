package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.Konsultasi;
import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.service.SiswaDashboardService;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

@RolesAllowed("SISWA")
@Route("siswa-dashboard")
public class SiswaDashboardView extends AppLayout implements BeforeEnterObserver {

    private final SiswaDashboardService dashboardService;
    private final VerticalLayout contentArea = new VerticalLayout();

    public SiswaDashboardView(SiswaDashboardService dashboardService) {
        this.dashboardService = dashboardService;

        getElement().getStyle().set("width", "100%").set("height", "100%");
        getElement().getStyle().set("background-color", "#f8fafc");

        contentArea.setSizeFull();
        contentArea.setPadding(true);
        contentArea.setSpacing(true);
        contentArea.getStyle().set("overflow-y", "auto");

        addToDrawer(createSidebar());
        setContent(contentArea);
        
        buildDashboardContent();
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        if (currentUser == null) {
            event.forwardTo("login");
        }
    }

    private VerticalLayout createSidebar() {
        VerticalLayout sidebar = new VerticalLayout();
        sidebar.setWidth("280px");
        sidebar.setHeightFull();
        sidebar.getStyle()
                .set("background-color", "#ffffff")
                .set("border-right", "1px solid #e2e8f0")
                .set("padding", "0px");

        HorizontalLayout logoLayout = new HorizontalLayout();
        logoLayout.setAlignItems(FlexComponent.Alignment.CENTER);
        logoLayout.getStyle().set("padding", "24px 20px 20px 20px").set("border-bottom", "1px solid #f1f5f9");
        logoLayout.setWidthFull();

        Icon logoIcon = VaadinIcon.ACADEMY_CAP.create();
        logoIcon.getStyle().set("color", "#2563eb").set("width", "18px").set("height", "18px");

        Span logoText = new Span("Portal Siswa");
        logoText.getStyle().set("font-weight", "700").set("color", "#1e293b").set("font-size", "15px").set("margin-left", "8px");

        logoLayout.add(logoIcon, logoText);

        VerticalLayout menuLayout = new VerticalLayout();
        menuLayout.setPadding(false);
        menuLayout.setSpacing(true);
        menuLayout.getStyle().set("padding", "16px 12px");

        menuLayout.add(
                createMenuButton("Dashboard", VaadinIcon.DASHBOARD, "siswa-dashboard"),
                createMenuButton("Laporan Kasus", VaadinIcon.WARNING, "siswa-laporan"),
                createMenuButton("Ajukan Konsultasi", VaadinIcon.EDIT, "siswa-ajukan-konsultasi"),
                createMenuButton("Riwayat Konsultasi", VaadinIcon.CLOCK, "siswa-riwayat"),
                createMenuButton("Jadwal Konseling", VaadinIcon.CALENDAR, "siswa-jadwal")
        );

        sidebar.add(logoLayout, menuLayout);
        sidebar.expand(menuLayout);
        sidebar.add(createProfileFooter());

        return sidebar;
    }

    private Button createMenuButton(String text, VaadinIcon icon, String routePath) {
        Button btn = new Button(text, icon.create());
        btn.setWidthFull();
        btn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        btn.getStyle()
                .set("justify-content", "flex-start")
                .set("padding", "12px 16px")
                .set("border-radius", "10px")
                .set("font-size", "14px")
                .set("color", "#475569")
                .set("background-color", "transparent")
                .set("font-weight", "500");

        if (btn.getIcon() != null) {
            btn.getIcon().getStyle().set("color", "#64748b");
        }

        btn.addClickListener(e -> UI.getCurrent().navigate(routePath));
        return btn;
    }

    private VerticalLayout createProfileFooter() {
        VerticalLayout footer = new VerticalLayout();
        footer.setWidthFull();
        footer.getStyle()
                .set("padding", "16px 20px 24px 20px")
                .set("border-top", "1px solid #f1f5f9")
                .set("background-color", "#ffffff");
        footer.setSpacing(false);
        footer.setPadding(false);

        User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        String nama = (currentUser != null && currentUser.getNamaLengkap() != null) ? currentUser.getNamaLengkap() : "Anisa Rahmawati";
        String nis = (currentUser != null && currentUser.getNisn() != null) ? currentUser.getNisn() : "2024001";
        String kelas = (currentUser != null && currentUser.getKelas() != null) ? currentUser.getKelas() : "XII RPL 1";

        HorizontalLayout profileInfo = new HorizontalLayout();
        profileInfo.setAlignItems(FlexComponent.Alignment.CENTER);
        profileInfo.getStyle().set("margin-bottom", "12px");

        Div avatar = new Div(new Span("AR"));
        avatar.getStyle()
                .set("width", "36px")
                .set("height", "36px")
                .set("background-color", "#dbeafe")
                .set("color", "#1d4ed8")
                .set("border-radius", "50%")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("font-weight", "700")
                .set("font-size", "13px")
                .set("flex-shrink", "0");

        VerticalLayout nameDesc = new VerticalLayout();
        nameDesc.setPadding(false);
        nameDesc.setSpacing(false);

        Span nameSpan = new Span(nama);
        nameSpan.getStyle().set("font-weight", "700").set("color", "#0f172a").set("font-size", "13px");

        Span roleSpan = new Span(kelas + " · NIS: " + nis);
        roleSpan.getStyle().set("color", "#64748b").set("font-size", "11px");

        nameDesc.add(nameSpan, roleSpan);
        profileInfo.add(avatar, nameDesc);

        Button logoutBtn = new Button("Logout", VaadinIcon.SIGN_OUT.create());
        logoutBtn.setWidthFull();
        logoutBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ERROR);
        logoutBtn.getStyle()
                .set("justify-content", "flex-start")
                .set("color", "#dc2626")
                .set("font-weight", "600")
                .set("font-size", "13px")
                .set("padding", "8px 12px");
        logoutBtn.getIcon().getStyle().set("color", "#dc2626");

        logoutBtn.addClickListener(e -> {
            SecurityContextHolder.clearContext();
            if (VaadinService.getCurrentRequest() != null) {
                VaadinService.getCurrentRequest().getWrappedSession().invalidate();
            }
            UI.getCurrent().getPage().setLocation("login");
        });

        footer.add(profileInfo, logoutBtn);
        return footer;
    }

    private void buildDashboardContent() {
        contentArea.removeAll();

        User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        String namaSiswa = (currentUser != null && currentUser.getNamaLengkap() != null) ? currentUser.getNamaLengkap() : "Anisa Rahmawati";
        String nisSiswa = (currentUser != null && currentUser.getNisn() != null) ? currentUser.getNisn() : "2024001";
        String kelasSiswa = (currentUser != null && currentUser.getKelas() != null) ? currentUser.getKelas() : "XII RPL 1";

        long totalKonsultasi = dashboardService.getTotalKonsultasi(nisSiswa);
        long menunggu = dashboardService.getKonsultasiByStatus(nisSiswa, "PENDING");
        long diproses = dashboardService.getKonsultasiByStatus(nisSiswa, "DIPROSES");
        long selesai = dashboardService.getKonsultasiByStatus(nisSiswa, "SELESAI");

        VerticalLayout welcomeBanner = new VerticalLayout();
        welcomeBanner.setWidthFull();
        welcomeBanner.getStyle()
                .set("background", "linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)")
                .set("border-radius", "16px")
                .set("padding", "28px 32px")
                .set("color", "#ffffff");
        
        H3 welcomeTitle = new H3("Selamat pagi, " + namaSiswa + " 👋");
        welcomeTitle.getStyle().set("margin", "0").set("color", "#ffffff").set("font-size", "22px");
        
        Paragraph welcomeSubtitle = new Paragraph(kelasSiswa + " · NIS: " + nisSiswa);
        welcomeSubtitle.getStyle().set("margin", "4px 0 0 0").set("color", "#93c5fd").set("font-size", "14px");
        
        welcomeBanner.add(welcomeTitle, welcomeSubtitle);

        HorizontalLayout statsLayout = new HorizontalLayout();
        statsLayout.setWidthFull();
        statsLayout.setSpacing(true);

        statsLayout.add(
                createStatCard(String.valueOf(totalKonsultasi), "Total Konsultasi", VaadinIcon.CHAT, "#eff6ff", "#2563eb"),
                createStatCard(String.valueOf(menunggu), "Menunggu", VaadinIcon.CLOCK, "#fffbeb", "#d97706"),
                createStatCard(String.valueOf(diproses), "Diproses", VaadinIcon.CHART_LINE, "#f5f3ff", "#7c3aed"),
                createStatCard(String.valueOf(selesai), "Selesai", VaadinIcon.CHECK_CIRCLE, "#f0fdf4", "#16a34a")
        );

        VerticalLayout historySection = new VerticalLayout();
        historySection.setWidthFull();
        historySection.getStyle()
                .set("background-color", "#ffffff")
                .set("border", "1px solid #e2e8f0")
                .set("border-radius", "14px")
                .set("padding", "20px")
                .set("margin-top", "20px");

        H4 historyTitle = new H4("Riwayat Konsultasi Terbaru");
        historyTitle.getStyle().set("margin-top", "0").set("color", "#0f172a");
        historySection.add(historyTitle);

        List<Konsultasi> riwayatList = dashboardService.getRiwayatKonsultasiTerbaru(nisSiswa);
        if (riwayatList.isEmpty()) {
            historySection.add(new Paragraph("Belum ada riwayat konsultasi."));
        } else {
            for (Konsultasi c : riwayatList) {
                HorizontalLayout row = new HorizontalLayout();
                row.setWidthFull();
                row.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
                
                // Menggunakan getTopik() sesuai Entity Konsultasi terbaru
                String topikText = (c.getTopik() != null ? c.getTopik() : "Tanpa Topik");
                String kategoriText = (c.getKategori() != null ? c.getKategori() : "-");
                Span topicSpan = new Span(topikText + " (" + kategoriText + ")");
                topicSpan.getStyle().set("font-size", "14px").set("color", "#334155").set("font-weight", "500");

                String statusVal = c.getStatus() != null ? c.getStatus() : "PENDING";
                Span statusSpan = new Span(statusVal);
                statusSpan.getStyle().set("font-size", "12px").set("font-weight", "600").set("padding", "4px 10px").set("border-radius", "6px");
                
                if ("SELESAI".equalsIgnoreCase(statusVal)) {
                    statusSpan.getStyle().set("background-color", "#f0fdf4").set("color", "#16a34a");
                } else if ("DIPROSES".equalsIgnoreCase(statusVal)) {
                    statusSpan.getStyle().set("background-color", "#f5f3ff").set("color", "#7c3aed");
                } else {
                    statusSpan.getStyle().set("background-color", "#fffbeb").set("color", "#d97706");
                }

                row.add(topicSpan, statusSpan);
                historySection.add(row);
            }
        }

        contentArea.add(welcomeBanner, statsLayout, historySection);
    }

    private VerticalLayout createStatCard(String value, String label, VaadinIcon iconEnum, String bgColor, String textColor) {
        VerticalLayout card = new VerticalLayout();
        card.setWidth("100%");
        card.getStyle()
                .set("background-color", "#ffffff")
                .set("border", "1px solid #e2e8f0")
                .set("border-radius", "14px")
                .set("padding", "20px");
        card.setSpacing(false);

        HorizontalLayout topRow = new HorizontalLayout();
        topRow.setWidthFull();
        topRow.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
        topRow.setAlignItems(FlexComponent.Alignment.CENTER);

        Span valSpan = new Span(value);
        valSpan.getStyle().set("font-size", "24px").set("font-weight", "700").set("color", "#0f172a");

        Icon icon = iconEnum.create();
        icon.getStyle().set("width", "18px").set("height", "18px").set("color", textColor);

        Div iconDiv = new Div(icon);
        iconDiv.getStyle()
                .set("background-color", bgColor)
                .set("width", "36px")
                .set("height", "36px")
                .set("border-radius", "10px")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center");

        topRow.add(valSpan, iconDiv);

        Span labelSpan = new Span(label);
        labelSpan.getStyle().set("font-size", "13px").set("color", "#64748b").set("margin-top", "8px");

        card.add(topRow, labelSpan);
        return card;
    }
}