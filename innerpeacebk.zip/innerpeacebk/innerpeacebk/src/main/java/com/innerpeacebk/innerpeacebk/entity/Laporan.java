package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "laporan")
public class Laporan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_laporan;

    @Column(name = "id_siswa")
    private Long idSiswa;

    @Column(name = "id_kategori")
    private Long idKategori;

    private String judul;

    @Column(columnDefinition = "TEXT")
    private String kronologi;

    private String lokasi;

    @Column(name = "tanggal_kejadian")
    private LocalDate tanggalKejadian;

    private String status; // Contoh: PENDING, DIPROSES, SELESAI

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        if (this.status == null) {
            this.status = "PENDING";
        }
    }

    // Getters and Setters
    public Long getId_laporan() {
        return id_laporan;
    }

    public void setId_laporan(Long id_laporan) {
        this.id_laporan = id_laporan;
    }

    public Long getIdSiswa() {
        return idSiswa;
    }

    public void setIdSiswa(Long idSiswa) {
        this.idSiswa = idSiswa;
    }

    public Long getIdKategori() {
        return idKategori;
    }

    public void setIdKategori(Long idKategori) {
        this.idKategori = idKategori;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getKronologi() {
        return kronologi;
    }

    public void setKronologi(String kronologi) {
        this.kronologi = kronologi;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public LocalDate getTanggalKejadian() {
        return tanggalKejadian;
    }

    public void setTanggalKejadian(LocalDate tanggalKejadian) {
        this.tanggalKejadian = tanggalKejadian;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}