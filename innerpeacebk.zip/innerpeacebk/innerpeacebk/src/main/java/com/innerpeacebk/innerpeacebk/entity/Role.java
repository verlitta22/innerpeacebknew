package com.innerpeacebk.innerpeacebk.entity;

public enum Role {
    SISWA,
    GURU_BK
}