package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.AjukanKonsultasi;
import com.innerpeacebk.innerpeacebk.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AjukanKonsultasiRepository extends JpaRepository<AjukanKonsultasi, Long> {
    List<AjukanKonsultasi> findBySiswa(User siswa);
}