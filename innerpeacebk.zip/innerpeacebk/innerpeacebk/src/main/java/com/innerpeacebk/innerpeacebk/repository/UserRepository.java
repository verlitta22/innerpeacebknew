package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByNisn(String nisn);
    
    // Tambahkan method ini untuk mengambil semua user berdasarkan rolenya saja (tanpa filter status)
    List<User> findByRole(User.Role role);
    
    // Method untuk mengambil daftar siswa berdasarkan status verifikasi
    List<User> findByRoleAndStatus(User.Role role, User.StatusAcc status);
}