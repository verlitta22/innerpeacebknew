package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Route("register")
@PageTitle("Buat Akun Siswa - InnerPeaceBK")
@AnonymousAllowed
public class RegisterView extends VerticalLayout {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Field Form Registrasi
    private final TextField namaLengkapField = new TextField("Nama Lengkap *");
    private final TextField nisField = new TextField("Nomor Induk Siswa (NIS) *");
    private final ComboBox<String> kelasComboBox = new ComboBox<>("Kelas *");
    private final TextField noHpField = new TextField("Nomor Handphone *");
    
    private final TextField usernameField = new TextField("Username *");
    private final PasswordField passwordField = new PasswordField("Password *");
    private final PasswordField confirmPasswordField = new PasswordField("Konfirmasi Password *");
    
    private final Checkbox agreementCheckbox = new Checkbox("Saya menyatakan bahwa seluruh data yang saya masukkan adalah benar dan dapat dipertanggungjawabkan.");
    private final Button registerButton = new Button("Daftar Sekarang");

    // Buffer dan Upload Component untuk Kartu Pelajar
    private final MemoryBuffer buffer = new MemoryBuffer();
    private final Upload uploadKartuPelajar = new Upload(buffer);
    private String savedFileName = ""; 
    private boolean isFileUploaded = false; // Penanda sukses upload

    public RegisterView(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

        setSizeFull();
        setAlignItems(Alignment.CENTER);
        setJustifyContentMode(FlexComponent.JustifyContentMode.START);
        getStyle()
                .set("background-color", "#ffffff")
                .set("padding", "30px 20px")
                .set("overflow-y", "auto");

        add(createFormContainer());
    }

    private Div createFormContainer() {
        Div container = new Div();
        container.setWidth("100%");
        container.setMaxWidth("500px");

        VerticalLayout content = new VerticalLayout();
        content.setPadding(false);
        content.setSpacing(false);
        content.setAlignItems(Alignment.STRETCH);

        // 1. Link Kembali ke Login
        RouterLink backLink = new RouterLink("Kembali ke Login", LoginView.class);
        backLink.getStyle()
                .set("color", "#64748b")
                .set("font-size", "14px")
                .set("font-weight", "500")
                .set("text-decoration", "none")
                .set("margin-bottom", "24px");

        // 2. Judul & Subjudul
        H2 title = new H2("Buat Akun Siswa");
        title.getStyle()
                .set("margin", "0 0 6px 0")
                .set("color", "#0f172a")
                .set("font-size", "26px")
                .set("font-weight", "800");

        Paragraph subtitle = new Paragraph("Lengkapi data di bawah ini untuk membuat akun InnerPeaceBK.");
        subtitle.getStyle()
                .set("margin", "0 0 24px 0")
                .set("color", "#64748b")
                .set("font-size", "14px");

        // --- BAGIAN 1: DATA PRIBADI ---
        Span section1 = new Span("1. Data Pribadi");
        section1.getStyle().set("font-weight", "700").set("color", "#1e293b").set("margin-bottom", "12px").set("display", "block");

        namaLengkapField.setPlaceholder("Masukkan nama lengkap");
        namaLengkapField.setWidthFull();
        namaLengkapField.getStyle().set("margin-bottom", "12px");

        nisField.setPlaceholder("Contoh: 2024001");
        nisField.setWidthFull();
        nisField.getStyle().set("margin-bottom", "12px");

        kelasComboBox.setPlaceholder("Pilih kelas");
        kelasComboBox.setItems("X RPL 1", "X RPL 2", "XI RPL 1", "XI RPL 2", "XII RPL 1", "XII RPL 2");
        kelasComboBox.setWidthFull();
        kelasComboBox.getStyle().set("margin-bottom", "12px");

        noHpField.setPlaceholder("Contoh: 08123456789");
        noHpField.setWidthFull();
        noHpField.getStyle().set("margin-bottom", "24px");

        // --- BAGIAN 2: DATA AKUN ---
        Span section2 = new Span("2. Data Akun");
        section2.getStyle().set("font-weight", "700").set("color", "#1e293b").set("margin-bottom", "12px").set("display", "block");

        usernameField.setPlaceholder("Buat username unik");
        usernameField.setWidthFull();
        usernameField.getStyle().set("margin-bottom", "12px");

        passwordField.setPlaceholder("Minimal 8 karakter");
        passwordField.setWidthFull();
        passwordField.getStyle().set("margin-bottom", "12px");

        confirmPasswordField.setPlaceholder("Ulangi password");
        confirmPasswordField.setWidthFull();
        confirmPasswordField.getStyle().set("margin-bottom", "24px");

        // --- BAGIAN 3: VERIFIKASI IDENTITAS (UPLOAD KARTU PELAJAR) ---
        Span section3 = new Span("3. Verifikasi Identitas");
        section3.getStyle().set("font-weight", "700").set("color", "#1e293b").set("margin-bottom", "4px").set("display", "block");

        Span uploadLabel = new Span("Upload Kartu Pelajar");
        uploadLabel.getStyle().set("font-size", "13px").set("color", "#64748b").set("margin-bottom", "8px").set("display", "block");

        // Konfigurasi Komponen Upload Vaadin
        uploadKartuPelajar.setAcceptedFileTypes("image/jpeg", "image/png", "image/jpg");
        uploadKartuPelajar.setMaxFileSize(5 * 1024 * 1024); // Maksimal 5 MB
        uploadKartuPelajar.setDropLabel(new Span("Klik atau drag & drop foto kartu pelajar"));
        uploadKartuPelajar.setDropLabelIcon(VaadinIcon.UPLOAD.create());
        
        // Listener ketika file berhasil di-upload ke server
        uploadKartuPelajar.addSucceededListener(event -> {
            try {
                String uploadDir = "uploads/";
                File directory = new File(uploadDir);
                if (!directory.exists()) {
                    directory.mkdirs();
                }

                String originalFilename = event.getFileName();
                String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
                savedFileName = "kartu_" + UUID.randomUUID().toString() + extension;

                Path targetPath = Paths.get(uploadDir + savedFileName);
                try (InputStream inputStream = buffer.getInputStream()) {
                    Files.copy(inputStream, targetPath);
                }

                isFileUploaded = true;
                Notification.show("Foto kartu pelajar berhasil diunggah!", 2000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_SUCCESS);
            } catch (Exception e) {
                isFileUploaded = false;
                Notification.show("Gagal menyimpan file: " + e.getMessage(), 4000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
            }
        });

        uploadKartuPelajar.addFailedListener(event -> {
            isFileUploaded = false;
            Notification.show("Upload gagal dilakukan.", 3000, Notification.Position.MIDDLE)
                    .addThemeVariants(NotificationVariant.LUMO_ERROR);
        });

        uploadKartuPelajar.getStyle().set("margin-bottom", "16px");

        agreementCheckbox.getStyle().set("font-size", "13px").set("color", "#475569").set("margin-bottom", "20px");

        // Tombol Daftar
        registerButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        registerButton.setWidthFull();
        registerButton.getStyle()
                .set("background-color", "#60a5fa")
                .set("height", "48px")
                .set("border-radius", "10px")
                .set("font-size", "15px")
                .set("font-weight", "700")
                .set("cursor", "pointer")
                .set("margin-bottom", "20px");

        registerButton.addClickListener(e -> handleRegister());

        // Footer Login Link
        HorizontalLayout loginFooter = new HorizontalLayout();
        loginFooter.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        loginFooter.setWidthFull();
        loginFooter.setSpacing(false);
        loginFooter.getStyle().set("margin-bottom", "20px");

        Span hasAccountText = new Span("Sudah punya akun? ");
        hasAccountText.getStyle().set("color", "#64748b").set("font-size", "14px");

        RouterLink loginLink = new RouterLink("Masuk", LoginView.class);
        loginLink.getStyle()
                .set("color", "#2563eb")
                .set("font-weight", "700")
                .set("font-size", "14px")
                .set("text-decoration", "none")
                .set("margin-left", "4px");

        loginFooter.add(hasAccountText, loginLink);

        // Informasi Status Pending Box
        Div infoBox = new Div();
        infoBox.getStyle()
                .set("background-color", "#eff6ff")
                .set("border", "1px solid #bfdbfe")
                .set("border-radius", "10px")
                .set("padding", "14px")
                .set("font-size", "12px")
                .set("color", "#1e40af");

        HorizontalLayout infoContent = new HorizontalLayout();
        infoContent.setSpacing(true);
        infoContent.setAlignItems(Alignment.START);
        Icon infoIcon = VaadinIcon.INFO_CIRCLE.create();
        infoIcon.getStyle().set("color", "#2563eb").set("min-width", "16px").set("min-height", "16px");
        
        Paragraph infoText = new Paragraph("Setelah registrasi berhasil, akun akan berstatus Menunggu Verifikasi. Guru BK akan memverifikasi data dan kartu pelajar yang telah diunggah. Akun baru dapat digunakan untuk login setelah proses verifikasi selesai.");
        infoText.getStyle().set("margin", "0");
        infoContent.add(infoIcon, infoText);
        infoBox.add(infoContent);

        // Susun komponen ke container utama
        content.add(
                backLink,
                title,
                subtitle,
                section1,
                namaLengkapField,
                nisField,
                kelasComboBox,
                noHpField,
                section2,
                usernameField,
                passwordField,
                confirmPasswordField,
                section3,
                uploadLabel,
                uploadKartuPelajar,
                agreementCheckbox,
                registerButton,
                loginFooter,
                infoBox
        );

        container.add(content);
        return container;
    }

    private void handleRegister() {
        String nama = namaLengkapField.getValue().trim();
        String nis = nisField.getValue().trim();
        String kelas = kelasComboBox.getValue();
        String noHp = noHpField.getValue().trim();
        String username = usernameField.getValue().trim();
        String password = passwordField.getValue();
        String confirmPassword = confirmPasswordField.getValue();

        // Validasi form kosong
        if (nama.isEmpty() || nis.isEmpty() || kelas == null || noHp.isEmpty() || username.isEmpty() || password.isEmpty()) {
            showNotification("Semua field bertanda * wajib diisi!", NotificationVariant.LUMO_ERROR);
            return;
        }

        // Validasi password match
        if (!password.equals(confirmPassword)) {
            showNotification("Password dan Konfirmasi Password tidak sama!", NotificationVariant.LUMO_ERROR);
            return;
        }

        // Validasi kartu pelajar wajib diunggah
        if (!isFileUploaded || savedFileName.isEmpty()) {
            showNotification("Silakan upload foto kartu pelajar terlebih dahulu dan tunggu hingga selesai!", NotificationVariant.LUMO_ERROR);
            return;
        }

        // Validasi centang persetujuan
        if (!agreementCheckbox.getValue()) {
            showNotification("Anda harus menyetujui pernyataan kebenaran data!", NotificationVariant.LUMO_ERROR);
            return;
        }

        // Cek apakah username sudah terdaftar
        if (userRepository.findByUsername(username).isPresent()) {
            showNotification("Username sudah digunakan, silakan pilih yang lain!", NotificationVariant.LUMO_ERROR);
            return;
        }

        try {
            // Simpan Data User Baru ke Database dengan status PENDING
            User newUser = new User();
            newUser.setNamaLengkap(nama);
            newUser.setNisn(nis);
            newUser.setKelas(kelas);
            // Jika entity User Anda memiliki setter noHp, aktifkan baris di bawah:
            // newUser.setNoHp(noHp); 
            newUser.setUsername(username);
            newUser.setPassword(passwordEncoder.encode(password));
            newUser.setRole(User.Role.SISWA);
            newUser.setStatus(User.StatusAcc.PENDING);
            newUser.setKartuPelajarPath("uploads/" + savedFileName);

            userRepository.save(newUser);

            Notification.show("Registrasi berhasil! Akun Anda menunggu verifikasi.", 4000, Notification.Position.TOP_CENTER)
                    .addThemeVariants(NotificationVariant.LUMO_SUCCESS);

            UI.getCurrent().navigate(LoginView.class);
        } catch (Exception e) {
            Notification.show("Terjadi kesalahan sistem: " + e.getMessage(), 5000, Notification.Position.MIDDLE)
                    .addThemeVariants(NotificationVariant.LUMO_ERROR);
        }
    }

    private void showNotification(String message, NotificationVariant variant) {
        Notification notification = Notification.show(message, 3000, Notification.Position.TOP_CENTER);
        notification.addThemeVariants(variant);
    }
}