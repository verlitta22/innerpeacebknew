package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.entity.StatusKasus; // Pastikan import enum StatusKasus jika ada
import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.security.core.context.SecurityContextHolder;
import java.time.LocalDateTime;

@RolesAllowed("SISWA")
@Route("siswa-laporan")
public class LaporanKasusView extends AppLayout implements BeforeEnterObserver {

    private final LaporanKasusRepository laporanKasusRepository;
    private final VerticalLayout contentArea = new VerticalLayout();

    private Long selectedKategoriId = null;
    private String selectedKategoriNama = "";
    private final TextField tfJudul = new TextField("Judul Kasus *");
    private final DatePicker dpTanggal = new DatePicker("Tanggal Kejadian *");
    private final TextField tfLokasi = new TextField("Lokasi Kejadian *");
    private final RadioButtonGroup<String> rbPelaporSebagai = new RadioButtonGroup<>();
    
    private final TextArea taKronologi = new TextArea("Kronologi Kejadian *");
    private final RadioButtonGroup<String> rbPrivasi = new RadioButtonGroup<>();

    private int currentStep = 1;

    public LaporanKasusView(LaporanKasusRepository laporanKasusRepository) {
        this.laporanKasusRepository = laporanKasusRepository;

        getElement().getStyle().set("width", "100%").set("height", "100%");
        getElement().getStyle().set("background-color", "#f8fafc");

        contentArea.setSizeFull();
        contentArea.setPadding(true);
        contentArea.setSpacing(true);
        contentArea.getStyle().set("overflow-y", "auto");

        addToDrawer(createSidebar());
        setContent(contentArea);

        renderStepContent();
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        if (currentUser == null) {
            event.forwardTo("login");
        }
    }

    private VerticalLayout createSidebar() {
        VerticalLayout sidebar = new VerticalLayout();
        sidebar.setWidth("280px");
        sidebar.setHeightFull();
        sidebar.getStyle()
                .set("background-color", "#ffffff")
                .set("border-right", "1px solid #e2e8f0")
                .set("padding", "0px");

        HorizontalLayout logoLayout = new HorizontalLayout();
        logoLayout.setAlignItems(FlexComponent.Alignment.CENTER);
        logoLayout.getStyle().set("padding", "24px 20px 20px 20px").set("border-bottom", "1px solid #f1f5f9");
        logoLayout.setWidthFull();

        Icon logoIcon = VaadinIcon.ACADEMY_CAP.create();
        logoIcon.getStyle().set("color", "#2563eb").set("width", "18px").set("height", "18px");

        Span logoText = new Span("Portal Siswa");
        logoText.getStyle().set("font-weight", "700").set("color", "#1e293b").set("font-size", "15px").set("margin-left", "8px");

        logoLayout.add(logoIcon, logoText);

        VerticalLayout menuLayout = new VerticalLayout();
        menuLayout.setPadding(false);
        menuLayout.setSpacing(true);
        menuLayout.getStyle().set("padding", "16px 12px");

        menuLayout.add(
                createMenuButton("Dashboard", VaadinIcon.DASHBOARD, "siswa-dashboard"),
                createMenuButton("Laporan Kasus", VaadinIcon.WARNING, "siswa-laporan"),
                createMenuButton("Ajukan Konsultasi", VaadinIcon.EDIT, "siswa-ajukan-konsultasi"),
                createMenuButton("Riwayat Konsultasi", VaadinIcon.CLOCK, "siswa-riwayat"),
                createMenuButton("Jadwal Konseling", VaadinIcon.CALENDAR, "siswa-jadwal")
        );

        sidebar.add(logoLayout, menuLayout);
        sidebar.expand(menuLayout);
        sidebar.add(createProfileFooter());

        return sidebar;
    }

    private Button createMenuButton(String text, VaadinIcon icon, String routePath) {
        Button btn = new Button(text, icon.create());
        btn.setWidthFull();
        btn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        boolean isActive = routePath.equals("siswa-laporan");
        btn.getStyle()
                .set("justify-content", "flex-start")
                .set("padding", "12px 16px")
                .set("border-radius", "10px")
                .set("font-size", "14px")
                .set("color", isActive ? "#2563eb" : "#475569")
                .set("background-color", isActive ? "#eff6ff" : "transparent")
                .set("font-weight", isActive ? "600" : "500");

        if (btn.getIcon() != null) {
            btn.getIcon().getStyle().set("color", isActive ? "#2563eb" : "#64748b");
        }

        btn.addClickListener(e -> UI.getCurrent().navigate(routePath));
        return btn;
    }

    private VerticalLayout createProfileFooter() {
        VerticalLayout footer = new VerticalLayout();
        footer.setWidthFull();
        footer.getStyle()
                .set("padding", "16px 20px 24px 20px")
                .set("border-top", "1px solid #f1f5f9")
                .set("background-color", "#ffffff");
        footer.setSpacing(false);
        footer.setPadding(false);

        User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        String nama = (currentUser != null && currentUser.getNamaLengkap() != null) ? currentUser.getNamaLengkap() : "Anisa Rahmawati";

        HorizontalLayout profileInfo = new HorizontalLayout();
        profileInfo.setAlignItems(FlexComponent.Alignment.CENTER);
        profileInfo.getStyle().set("margin-bottom", "12px");

        Div avatar = new Div(new Span("AR"));
        avatar.getStyle()
                .set("width", "36px")
                .set("height", "36px")
                .set("background-color", "#dbeafe")
                .set("color", "#1d4ed8")
                .set("border-radius", "50%")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("font-weight", "700")
                .set("font-size", "13px")
                .set("flex-shrink", "0");

        VerticalLayout nameDesc = new VerticalLayout();
        nameDesc.setPadding(false);
        nameDesc.setSpacing(false);

        Span nameSpan = new Span(nama);
        nameSpan.getStyle().set("font-weight", "700").set("color", "#0f172a").set("font-size", "13px");

        Span roleSpan = new Span("XII RPL 1 · NIS: 2024001");
        roleSpan.getStyle().set("color", "#64748b").set("font-size", "11px");

        nameDesc.add(nameSpan, roleSpan);
        profileInfo.add(avatar, nameDesc);

        Button logoutBtn = new Button("Logout", VaadinIcon.SIGN_OUT.create());
        logoutBtn.setWidthFull();
        logoutBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ERROR);
        logoutBtn.getStyle()
                .set("justify-content", "flex-start")
                .set("color", "#dc2626")
                .set("font-weight", "600")
                .set("font-size", "13px")
                .set("padding", "8px 12px");
        logoutBtn.getIcon().getStyle().set("color", "#dc2626");

        logoutBtn.addClickListener(e -> {
            SecurityContextHolder.clearContext();
            if (VaadinService.getCurrentRequest() != null) {
                VaadinService.getCurrentRequest().getWrappedSession().invalidate();
            }
            UI.getCurrent().getPage().setLocation("login");
        });

        footer.add(profileInfo, logoutBtn);
        return footer;
    }

    private void renderStepContent() {
        contentArea.removeAll();

        H2 pageTitle = new H2("Laporan Kasus");
        pageTitle.getStyle().set("margin", "0 0 4px 0").set("color", "#0f172a");
        Paragraph subtitle = new Paragraph("Laporkan kejadian yang kamu alami atau saksikan.");
        subtitle.getStyle().set("color", "#64748b").set("margin", "0 0 20px 0");

        HorizontalLayout stepperLayout = createStepperHeader();

        VerticalLayout cardContainer = new VerticalLayout();
        cardContainer.setWidthFull();
        cardContainer.setMaxWidth("900px");
        cardContainer.getStyle()
                .set("background-color", "#ffffff")
                .set("border", "1px solid #e2e8f0")
                .set("border-radius", "16px")
                .set("padding", "32px")
                .set("box-shadow", "0 1px 3px 0 rgb(0 0 0 / 0.1)");

        if (currentStep == 1) {
            cardContainer.add(buildStep1Content());
        } else if (currentStep == 2) {
            cardContainer.add(buildStep2Content());
        } else {
            cardContainer.add(buildStep3Content());
        }

        contentArea.add(pageTitle, subtitle, stepperLayout, cardContainer);
    }

    private HorizontalLayout createStepperHeader() {
        HorizontalLayout layout = new HorizontalLayout();
        layout.setAlignItems(FlexComponent.Alignment.CENTER);
        layout.getStyle().set("margin-bottom", "20px");

        layout.add(
                createStepBadge(1, "Informasi Kasus", currentStep >= 1),
                createDividerLine(),
                createStepBadge(2, "Kronologi", currentStep >= 2),
                createDividerLine(),
                createStepBadge(3, "Bukti & Privasi", currentStep >= 3)
        );

        return layout;
    }

    private HorizontalLayout createStepBadge(int stepNum, String label, boolean isActive) {
        Div circle = new Div(new Span(String.valueOf(stepNum)));
        circle.getStyle()
                .set("width", "28px")
                .set("height", "28px")
                .set("border-radius", "50%")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("font-weight", "600")
                .set("font-size", "12px")
                .set("background-color", isActive ? "#2563eb" : "#e2e8f0")
                .set("color", isActive ? "#ffffff" : "#64748b");

        Span text = new Span(label);
        text.getStyle()
                .set("font-size", "14px")
                .set("font-weight", isActive ? "600" : "400")
                .set("color", isActive ? "#1e293b" : "#64748b")
                .set("margin-left", "8px");

        HorizontalLayout hl = new HorizontalLayout(circle, text);
        hl.setAlignItems(FlexComponent.Alignment.CENTER);
        return hl;
    }

    private Hr createDividerLine() {
        Hr hr = new Hr();
        hr.getStyle().set("flex-grow", "1").set("border", "none").set("border-top", "1px solid #cbd5e1").set("margin", "0 16px");
        return hr;
    }

    private VerticalLayout buildStep1Content() {
        VerticalLayout v = new VerticalLayout();
        v.setPadding(false);
        v.setSpacing(true);

        H3 title = new H3("Informasi Kasus");
        title.getStyle().set("margin", "0").set("color", "#0f172a");
        Paragraph desc = new Paragraph("Lengkapi informasi dasar tentang kejadian yang dilaporkan.");
        desc.getStyle().set("color", "#64748b").set("margin", "0 0 16px 0");

        Span catLabel = new Span("Kategori Kasus *");
        catLabel.getStyle().set("font-weight", "600").set("font-size", "13px").set("color", "#334155");

        HorizontalLayout catRow1 = new HorizontalLayout();
        catRow1.setWidthFull();
        catRow1.add(
                createCategoryButton("Bullying", 1L),
                createCategoryButton("Kekerasan", 2L),
                createCategoryButton("Pelecehan", 3L),
                createCategoryButton("Tawuran", 4L)
        );

        HorizontalLayout catRow2 = new HorizontalLayout();
        catRow2.setWidthFull();
        catRow2.add(
                createCategoryButton("Vandalisme", 5L),
                createCategoryButton("Pencurian", 6L),
                createCategoryButton("Narkoba", 7L),
                createCategoryButton("Lainnya", 8L)
        );

        tfJudul.setWidthFull();
        tfJudul.setPlaceholder("Contoh: Bullying di kelas X TKJ 2");

        HorizontalLayout dateLocLayout = new HorizontalLayout();
        dateLocLayout.setWidthFull();
        dpTanggal.setWidthFull();
        tfLokasi.setWidthFull();
        tfLokasi.setPlaceholder("Contoh: Kelas X TKJ 2, Kantin");
        dateLocLayout.add(dpTanggal, tfLokasi);

        rbPelaporSebagai.setLabel("Pelapor Sebagai *");
        rbPelaporSebagai.setItems("Korban", "Saksi", "Teman Korban");

        HorizontalLayout btnLayout = new HorizontalLayout();
        btnLayout.setWidthFull();
        btnLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
        btnLayout.getStyle().set("margin-top", "24px");

        Button nextBtn = new Button("Selanjutnya", VaadinIcon.ARROW_RIGHT.create());
        nextBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        nextBtn.setIconAfterText(true);
        nextBtn.addClickListener(e -> {
            if (selectedKategoriId == null || tfJudul.isEmpty() || dpTanggal.isEmpty() || tfLokasi.isEmpty() || rbPelaporSebagai.isEmpty()) {
                Notification.show("Mohon lengkapi semua field wajib di step 1!", 3000, Notification.Position.MIDDLE)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
                return;
            }
            currentStep = 2;
            renderStepContent();
        });

        btnLayout.add(nextBtn);
        v.add(title, desc, catLabel, catRow1, catRow2, tfJudul, dateLocLayout, rbPelaporSebagai, btnLayout);
        return v;
    }

    private Button createCategoryButton(String label, Long id) {
        Button btn = new Button(label);
        btn.setWidthFull();
        boolean isSelected = (selectedKategoriId != null && selectedKategoriId.equals(id));
        
        btn.getStyle()
                .set("border-radius", "8px")
                .set("border", isSelected ? "2px solid #2563eb" : "1px solid #cbd5e1")
                .set("background-color", isSelected ? "#eff6ff" : "#ffffff")
                .set("color", isSelected ? "#2563eb" : "#334155")
                .set("font-weight", isSelected ? "600" : "400");

        btn.addClickListener(e -> {
            selectedKategoriId = id;
            selectedKategoriNama = label;
            renderStepContent();
        });

        return btn;
    }

    private VerticalLayout buildStep2Content() {
        VerticalLayout v = new VerticalLayout();
        v.setPadding(false);
        v.setSpacing(true);

        H3 title = new H3("Kronologi Kejadian");
        title.getStyle().set("margin", "0").set("color", "#0f172a");
        Paragraph desc = new Paragraph("Ceritakan kronologi kejadian secara jelas dan rinci.");
        desc.getStyle().set("color", "#64748b").set("margin", "0 0 16px 0");

        taKronologi.setWidthFull();
        taKronologi.setMinHeight("150px");
        taKronologi.setPlaceholder("Tuliskan detail kejadian, siapa yang terlibat, dan bagaimana kejadian berlangsung...");

        HorizontalLayout btnLayout = new HorizontalLayout();
        btnLayout.setWidthFull();
        btnLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
        btnLayout.getStyle().set("margin-top", "24px");

        Button backBtn = new Button("Kembali", VaadinIcon.ARROW_LEFT.create());
        backBtn.addClickListener(e -> {
            currentStep = 1;
            renderStepContent();
        });

        Button nextBtn = new Button("Selanjutnya", VaadinIcon.ARROW_RIGHT.create());
        nextBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        nextBtn.setIconAfterText(true);
        nextBtn.addClickListener(e -> {
            if (taKronologi.isEmpty()) {
                Notification.show("Kronologi kejadian wajib diisi!", 3000, Notification.Position.MIDDLE)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
                return;
            }
            currentStep = 3;
            renderStepContent();
        });

        btnLayout.add(backBtn, nextBtn);
        v.add(title, desc, taKronologi, btnLayout);
        return v;
    }

    private VerticalLayout buildStep3Content() {
        VerticalLayout v = new VerticalLayout();
        v.setPadding(false);
        v.setSpacing(true);

        H3 title = new H3("Bukti & Pengaturan Privasi");
        title.getStyle().set("margin", "0").set("color", "#0f172a");
        Paragraph desc = new Paragraph("Tentukan preferensi privasi pelapor.");
        desc.getStyle().set("color", "#64748b").set("margin", "0 0 16px 0");

        rbPrivasi.setLabel("Opsi Kerahasiaan Identitas *");
        rbPrivasi.setItems("Rahasiakan identitas saya dari pihak tertuduh", "Identitas terbuka kepada Guru BK");
        rbPrivasi.setValue("Rahasiakan identitas saya dari pihak tertuduh");

        HorizontalLayout btnLayout = new HorizontalLayout();
        btnLayout.setWidthFull();
        btnLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
        btnLayout.getStyle().set("margin-top", "24px");

        Button backBtn = new Button("Kembali", VaadinIcon.ARROW_LEFT.create());
        backBtn.addClickListener(e -> {
            currentStep = 2;
            renderStepContent();
        });

        Button submitBtn = new Button("Kirim Laporan", VaadinIcon.CHECK.create());
        submitBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        submitBtn.getStyle().set("background-color", "#16a34a");
        submitBtn.addClickListener(e -> {
            try {
                User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
                if (currentUser == null) {
                    Notification.show("Sesi login habis, silakan login ulang.", 3000, Notification.Position.MIDDLE)
                            .addThemeVariants(NotificationVariant.LUMO_ERROR);
                    UI.getCurrent().navigate("login");
                    return;
                }

                LaporanKasus laporan = new LaporanKasus();
                
                // Menetapkan objek User ke relasi pelapor (@ManyToOne)
                laporan.setPelapor(currentUser);
                
                laporan.setJudul(tfJudul.getValue());
                laporan.setLokasi(tfLokasi.getValue());
                
                // Konversi LocalDate dari DatePicker ke LocalDateTime
                if (dpTanggal.getValue() != null) {
                    laporan.setTanggalKejadian(dpTanggal.getValue().atStartOfDay());
                }
                
                laporan.setTanggalDibuat(LocalDateTime.now());
                
                String finalDeskripsi = "[Pelapor Sebagai: " + rbPelaporSebagai.getValue() + "]\n" +
                                        "[Privasi: " + rbPrivasi.getValue() + "]\n\n" + 
                                        taKronologi.getValue();
                laporan.setDeskripsi(finalDeskripsi);
                
                // Menggunakan Enum StatusKasus sesuai entity baru
                laporan.setStatus(StatusKasus.PENDING);

                laporanKasusRepository.save(laporan);

                Notification.show("Laporan berhasil dikirim!", 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_SUCCESS);

                UI.getCurrent().navigate("siswa-dashboard");
            } catch (Exception ex) {
                Notification.show("Gagal mengirim laporan: " + ex.getMessage(), 4000, Notification.Position.MIDDLE)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
            }
        });

        btnLayout.add(backBtn, submitBtn);
        v.add(title, desc, rbPrivasi, btnLayout);
        return v;
    }
}