package com.innerpeacebk.innerpeacebk.entity;

public class KategoriMasalah {
    
}
