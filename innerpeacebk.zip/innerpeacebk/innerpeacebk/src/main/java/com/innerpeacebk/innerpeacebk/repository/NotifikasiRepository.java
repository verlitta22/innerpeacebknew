package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.Notifikasi;
import com.innerpeacebk.innerpeacebk.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotifikasiRepository extends JpaRepository<Notifikasi, Long> {

    long countBySiswaAndDibacaFalse(User siswa);

    List<Notifikasi> findTop4BySiswaOrderByTanggalDesc(User siswa);
}