package com.innerpeacebk.innerpeacebk.entity;

public class Bukti {
    
}
