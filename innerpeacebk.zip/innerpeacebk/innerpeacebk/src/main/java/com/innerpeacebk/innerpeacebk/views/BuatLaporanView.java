package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.service.BkService;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.datetimepicker.DateTimePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;

import java.time.LocalDateTime;

@Route(value = "buat-laporan", layout = MainLayout.class)
@PageTitle("Buat Laporan Kasus | InnerPeaceBK")
@RolesAllowed("SISWA")
public class BuatLaporanView extends VerticalLayout {

    private final BkService bkService;

    private final TextField judul = new TextField("Judul Laporan / Kejadian");
    private final TextArea deskripsi = new TextArea("Deskripsi Kronologi Kejadian");
    private final TextField lokasi = new TextField("Lokasi Kejadian");
    private final DateTimePicker tanggalKejadian = new DateTimePicker("Waktu / Tanggal Kejadian");
    private final Checkbox anonim = new Checkbox("Laporkan Secara Anonim (Identitas Disembunyikan)");
    private final Button simpanBtn = new Button("Kirim Laporan");

    public BuatLaporanView(BkService bkService) {
        this.bkService = bkService;

        setSpacing(true);
        setMaxWidth("700px");

        H2 title = new H2("Form Pelaporan Kasus");

        judul.setRequired(true);
        judul.setPlaceholder("Contoh: Perundungan di Kantin");

        deskripsi.setRequired(true);
        deskripsi.setHeight("150px");
        deskripsi.setPlaceholder("Jelaskan detail kronologi kejadian secara mendalam...");

        lokasi.setPlaceholder("Contoh: Laboratorium Komputer / Lapangan Belakang");
        tanggalKejadian.setValue(LocalDateTime.now());

        simpanBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        simpanBtn.addClickListener(e -> simpanLaporan());

        FormLayout formLayout = new FormLayout();
        formLayout.add(judul, lokasi, tanggalKejadian, anonim, deskripsi);
        formLayout.setColspan(deskripsi, 2);
        formLayout.setColspan(anonim, 2);

        add(title, formLayout, simpanBtn);
    }

    private void simpanLaporan() {
        if (judul.isEmpty() || deskripsi.isEmpty()) {
            Notification.show("Silakan isi Judul dan Deskripsi Laporan terlebih dahulu!", 3000, Notification.Position.MIDDLE)
                    .addThemeVariants(NotificationVariant.LUMO_ERROR);
            return;
        }

        LaporanKasus laporan = new LaporanKasus();
        laporan.setJudul(judul.getValue());
        laporan.setDeskripsi(deskripsi.getValue());
        laporan.setLokasi(lokasi.getValue());
        laporan.setTanggalKejadian(tanggalKejadian.getValue());
        bkService.buatLaporan(laporan);

        Notification.show("Laporan kasus berhasil dikirim ke Guru BK!", 3000, Notification.Position.BOTTOM_START)
                .addThemeVariants(NotificationVariant.LUMO_SUCCESS);

        clearForm();
    }

    private void clearForm() {
        judul.clear();
        deskripsi.clear();
        lokasi.clear();
        tanggalKejadian.setValue(LocalDateTime.now());
        anonim.setValue(false);
    }
}