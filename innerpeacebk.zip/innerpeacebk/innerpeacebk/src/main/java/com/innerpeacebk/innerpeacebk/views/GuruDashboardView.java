package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasElement;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.security.core.context.SecurityContextHolder;

@RolesAllowed("GURU_BK")
@Route("guru-dashboard")
public class GuruDashboardView extends AppLayout implements BeforeEnterObserver {

    private final VerticalLayout contentArea = new VerticalLayout();

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        if (event.getLocation().getPath().equals("guru-dashboard")) {
            event.forwardTo("home");
        }
    }

    public GuruDashboardView() {
        getElement().getStyle().set("width", "100%").set("height", "100%");
        getElement().getStyle().set("background-color", "#f8fafc");

        contentArea.setSizeFull();
        contentArea.setPadding(false);
        contentArea.setSpacing(false);
        contentArea.getStyle().set("overflow-y", "auto");

        addToDrawer(createSidebar());
        setContent(contentArea);
    }

    @Override
    public void showRouterLayoutContent(HasElement content) {
        contentArea.removeAll();
        if (content != null) {
            contentArea.add((Component) content);
        }
    }

    private VerticalLayout createSidebar() {
        VerticalLayout sidebar = new VerticalLayout();
        sidebar.setWidth("280px");
        sidebar.setHeightFull();
        sidebar.getStyle()
                .set("background-color", "#ffffff")
                .set("border-right", "1px solid #e2e8f0")
                .set("padding", "0px");

        HorizontalLayout logoLayout = new HorizontalLayout();
        logoLayout.setAlignItems(FlexComponent.Alignment.CENTER);
        logoLayout.getStyle().set("padding", "24px 20px 20px 20px").set("border-bottom", "1px solid #f1f5f9");
        logoLayout.setWidthFull();

        Icon logoIcon = VaadinIcon.HEART.create();
        logoIcon.getStyle().set("color", "#2563eb").set("width", "18px").set("height", "18px");

        Span logoText = new Span("Portal Guru BK");
        logoText.getStyle().set("font-weight", "700").set("color", "#1e293b").set("font-size", "15px").set("margin-left", "8px");

        logoLayout.add(logoIcon, logoText);

        VerticalLayout menuLayout = new VerticalLayout();
        menuLayout.setPadding(false);
        menuLayout.setSpacing(true);
        menuLayout.getStyle().set("padding", "16px 12px");

        // Menu diperbarui: Statistik & Kategori Masalah dihapus, diganti dengan Report
        menuLayout.add(
                createMenuButton("Dashboard", VaadinIcon.DASHBOARD, "home"),
                createMenuButton("Data Laporan Kasus", VaadinIcon.WARNING, "laporan"),
                createMenuButton("Data Konsultasi", VaadinIcon.FILE_TEXT, "konsultasi"),
                createMenuButton("Data Siswa", VaadinIcon.USERS, "siswa"),
                createMenuButton("Report", VaadinIcon.CHART, "report")
        );

        sidebar.add(logoLayout, menuLayout);
        sidebar.expand(menuLayout); 
        sidebar.add(createProfileFooter());

        return sidebar;
    }

    private Button createMenuButton(String text, VaadinIcon icon, String routePath) {
        Button btn = new Button(text, icon.create());
        btn.setWidthFull();
        btn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        btn.getStyle()
                .set("justify-content", "flex-start")
                .set("padding", "12px 16px")
                .set("border-radius", "10px")
                .set("font-size", "14px")
                .set("color", "#475569")
                .set("background-color", "transparent")
                .set("font-weight", "500");

        if (btn.getIcon() != null) {
            btn.getIcon().getStyle().set("color", "#64748b");
        }

        btn.addClickListener(e -> {
            UI.getCurrent().navigate(routePath);
        });

        return btn;
    }

    private VerticalLayout createProfileFooter() {
        VerticalLayout footer = new VerticalLayout();
        footer.setWidthFull();
        footer.getStyle()
                .set("padding", "16px 20px 24px 20px")
                .set("border-top", "1px solid #f1f5f9")
                .set("background-color", "#ffffff");
        footer.setSpacing(false);
        footer.setPadding(false);

        User currentUser = VaadinSession.getCurrent().getAttribute(User.class);
        String nama = (currentUser != null && currentUser.getNamaLengkap() != null) ? currentUser.getNamaLengkap() : "Dra. Rina Susanti, M.Pd";

        HorizontalLayout profileInfo = new HorizontalLayout();
        profileInfo.setAlignItems(FlexComponent.Alignment.CENTER);
        profileInfo.getStyle().set("margin-bottom", "12px");

        Div avatar = new Div(new Span("RS"));
        avatar.getStyle()
                .set("width", "36px")
                .set("height", "36px")
                .set("background-color", "#dbeafe")
                .set("color", "#1d4ed8")
                .set("border-radius", "50%")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("font-weight", "700")
                .set("font-size", "13px")
                .set("flex-shrink", "0");

        VerticalLayout nameDesc = new VerticalLayout();
        nameDesc.setPadding(false);
        nameDesc.setSpacing(false);

        Span nameSpan = new Span(nama);
        nameSpan.getStyle().set("font-weight", "700").set("color", "#0f172a").set("font-size", "13px");

        Span roleSpan = new Span("Guru BK · SMKN 1 Contoh");
        roleSpan.getStyle().set("color", "#64748b").set("font-size", "11px");

        nameDesc.add(nameSpan, roleSpan);
        profileInfo.add(avatar, nameDesc);

        Button logoutBtn = new Button("Logout", VaadinIcon.SIGN_OUT.create());
        logoutBtn.setWidthFull();
        logoutBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ERROR);
        logoutBtn.getStyle()
                .set("justify-content", "flex-start")
                .set("color", "#dc2626")
                .set("font-weight", "600")
                .set("font-size", "13px")
                .set("padding", "8px 12px");
        logoutBtn.getIcon().getStyle().set("color", "#dc2626");

        logoutBtn.addClickListener(e -> {
            SecurityContextHolder.clearContext();
            if (VaadinService.getCurrentRequest() != null) {
                VaadinService.getCurrentRequest().getWrappedSession().invalidate();
            }
            UI.getCurrent().getPage().setLocation("login");
        });

        footer.add(profileInfo, logoutBtn);
        return footer;
    }
}