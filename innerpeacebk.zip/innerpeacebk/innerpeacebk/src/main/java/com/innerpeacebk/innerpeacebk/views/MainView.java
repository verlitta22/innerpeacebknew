package com.innerpeacebk.innerpeacebk.views;

import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

@Route("main") // URL diubah ke: http://localhost:8080/main
@PageTitle("Main - InnerPeaceBK")
@AnonymousAllowed
public class MainView extends VerticalLayout {

    public MainView() {
        add(new H1("Selamat Datang di InnerPeaceBK App"));
    }
}