package com.innerpeacebk.innerpeacebk.entity;

public enum StatusKonseling {
    MENUNGGU_KONFIRMASI,
    DIJADWALKAN,
    SELESAI,
    DITOLAK
}