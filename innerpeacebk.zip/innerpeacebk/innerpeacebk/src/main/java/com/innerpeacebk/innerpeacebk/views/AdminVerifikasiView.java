package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;

@Route(value = "admin-verifikasi", layout = GuruDashboardView.class)
@PageTitle("Verifikasi Akun Siswa | Portal Guru BK")
@RolesAllowed("GURU_BK")
@PermitAll
public class AdminVerifikasiView extends VerticalLayout {

    private final UserRepository userRepository;
    private Grid<User> grid;

    public AdminVerifikasiView(UserRepository userRepository) {
        this.userRepository = userRepository;

        setSizeFull();
        getStyle().set("padding", "32px").set("background-color", "#f8fafc");
        setSpacing(true);

        // Header Judul Halaman
        VerticalLayout headerLayout = new VerticalLayout();
        headerLayout.setPadding(false);
        headerLayout.setSpacing(false);
        
        H3 title = new H3("Verifikasi Akun Siswa");
        title.getStyle().set("color", "#0f172a").set("margin", "0").set("font-size", "20px");
        
        Span subtitle = new Span("Kelola dan setujui pendaftaran akun baru siswa yang masuk ke sistem.");
        subtitle.getStyle().set("color", "#64748b").set("font-size", "13px");
        
        headerLayout.add(title, subtitle);

        // Card Container untuk Tabel
        VerticalLayout cardContainer = new VerticalLayout();
        cardContainer.setWidthFull();
        cardContainer.getStyle()
                .set("background-color", "#ffffff")
                .set("border", "1px solid #e2e8f0")
                .set("border-radius", "12px")
                .set("padding", "20px")
                .set("box-shadow", "0 1px 3px 0 rgba(0, 0, 0, 0.05)");

        grid = new Grid<>(User.class, false);
        grid.addColumn(User::getNamaLengkap).setHeader("Nama Lengkap");
        grid.addColumn(User::getNisn).setHeader("NIS / NISN");
        grid.addColumn(User::getKelas).setHeader("Kelas");
        grid.addColumn(User::getUsername).setHeader("Username");

        grid.addComponentColumn(user -> {
            Button approveBtn = new Button("Setujui", VaadinIcon.CHECK.create(), e -> {
                user.setStatus(User.StatusAcc.APPROVED);
                userRepository.save(user);
                loadData();
                Notification.show("Akun " + user.getNamaLengkap() + " disetujui.", 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_SUCCESS);
            });
            approveBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_SUCCESS);

            Button rejectBtn = new Button("Tolak", VaadinIcon.CLOSE.create(), e -> {
                user.setStatus(User.StatusAcc.REJECTED);
                userRepository.save(user);
                loadData();
                Notification.show("Akun " + user.getNamaLengkap() + " ditolak.", 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
            });
            rejectBtn.addThemeVariants(ButtonVariant.LUMO_ERROR);

            return new HorizontalLayout(approveBtn, rejectBtn);
        }).setHeader("Aksi");

        loadData();
        cardContainer.add(grid);

        add(headerLayout, cardContainer);
    }

    private void loadData() {
        grid.setItems(userRepository.findByRoleAndStatus(User.Role.SISWA, User.StatusAcc.PENDING));
    }
}