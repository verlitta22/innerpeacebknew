package com.innerpeacebk.innerpeacebk;

import com.innerpeacebk.innerpeacebk.entity.*;
import com.innerpeacebk.innerpeacebk.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner loadData(UserRepository userRepository, 
                                       LaporanKasusRepository laporanRepo,
                                       SesiKonselingRepository konselingRepo,
                                       PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.count() == 0) {
                
                // 1. Akun Guru BK
                User guru = new User();
                guru.setUsername("gurubk");
                guru.setPassword(passwordEncoder.encode("guru123"));
                guru.setNamaLengkap("Ibu Rahmawati, S.Pd.");
                guru.setRole(User.Role.GURU_BK);
                guru.setStatus(User.StatusAcc.APPROVED);
                guru = userRepository.save(guru);

                // 2. Akun Siswa Approved (Langsung Bisa Login)
                User siswaApproved = new User();
                siswaApproved.setUsername("siswa");
                siswaApproved.setPassword(passwordEncoder.encode("siswa123"));
                siswaApproved.setNamaLengkap("Budi Santoso");
                siswaApproved.setNisn("1234567890");
                siswaApproved.setKelas("XI RPL 1");
                siswaApproved.setRole(User.Role.SISWA);
                siswaApproved.setStatus(User.StatusAcc.APPROVED);
                siswaApproved = userRepository.save(siswaApproved);

                // 3. Akun Siswa Pending (Untuk Uji Coba Verifikasi Guru)
                User siswaPending = new User();
                siswaPending.setUsername("siswa.pending@smk24.sch.id");
                siswaPending.setPassword(passwordEncoder.encode("siswa123"));
                siswaPending.setNamaLengkap("Siti Aminah");
                siswaPending.setNisn("0051234567");
                siswaPending.setKelas("X RPL 2");
                siswaPending.setKartuPelajarPath("uploads/sample_kartu.jpg");
                siswaPending.setRole(User.Role.SISWA);
                siswaPending.setStatus(User.StatusAcc.PENDING);
                userRepository.save(siswaPending);

                // 4. Contoh Laporan Kasus
                LaporanKasus laporan1 = new LaporanKasus();
                laporan1.setJudul("Perundungan Verbal di Kantin");
                laporan1.setDeskripsi("Terjadi ejekan berulang saat jam istirahat pertama.");
                laporan1.setLokasi("Kantin Belakang");
                laporan1.setTanggalKejadian(LocalDateTime.now().minusDays(1));
                laporan1.setPelapor(siswaApproved);
                laporan1.setStatus(StatusKasus.PENDING);
                laporanRepo.save(laporan1);

                // 5. Contoh Sesi Konseling
                SesiKonseling konseling1 = new SesiKonseling();
                konseling1.setTopik("Konsultasi Minat Kejuruan / Karir");
                konseling1.setKeluhan("Bingung memilih jurusan kuliah atau fokus kerja setelah lulus.");
                konseling1.setJadwalKonseling(LocalDateTime.now().plusDays(2));
                konseling1.setSiswa(siswaApproved);
                konseling1.setStatus(StatusKonseling.MENUNGGU_KONFIRMASI);
                konselingRepo.save(konseling1);

                System.out.println("==================================================");
                System.out.println(">>> DATA INITIALIZER: Sampel Data Berhasil Dibuat!");
                System.out.println("==================================================");
            }
        };
    }
}