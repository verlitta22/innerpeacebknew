package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import lombok.Data; // Pastikan Anda sudah menambahkan library Lombok di pom.xml

@Entity
@Table(name = "siswa")
@Data
public class Siswa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nama;
    private String nis;
    private String kelas;

    // Relasi ke tabel user (Opsional: jika tabel siswa terhubung ke tabel users)
    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;
}