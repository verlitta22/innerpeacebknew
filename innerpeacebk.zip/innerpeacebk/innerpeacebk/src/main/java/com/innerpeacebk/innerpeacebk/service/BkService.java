package com.innerpeacebk.innerpeacebk.service;

import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.entity.SesiKonseling;
import com.innerpeacebk.innerpeacebk.entity.StatusKasus;
import com.innerpeacebk.innerpeacebk.entity.StatusKonseling;
import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;
import com.innerpeacebk.innerpeacebk.repository.SesiKonselingRepository;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BkService {

    private final LaporanKasusRepository laporanRepo;
    private final SesiKonselingRepository konselingRepo;
    private final UserRepository userRepo;

    public BkService(LaporanKasusRepository laporanRepo, 
                     SesiKonselingRepository konselingRepo, 
                     UserRepository userRepo) {
        this.laporanRepo = laporanRepo;
        this.konselingRepo = konselingRepo;
        this.userRepo = userRepo;
    }

    // --- LOGIKA USER ---
    public Optional<User> getAuthenticatedUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByUsername(username);
    }

    // --- LOGIKA LAPORAN KASUS ---
    public LaporanKasus buatLaporan(LaporanKasus laporan) {
        getAuthenticatedUser().ifPresent(laporan::setPelapor);
        laporan.setStatus(StatusKasus.PENDING);
        return laporanRepo.save(laporan);
    }

    public List<LaporanKasus> getSemuaLaporan() {
        return laporanRepo.findAll();
    }

    public List<LaporanKasus> getLaporanSaya() {
        return getAuthenticatedUser()
                .map(laporanRepo::findByPelapor)
                .orElse(List.of());
    }

    public LaporanKasus updateStatusLaporan(Long id, StatusKasus status, String catatan) {
        LaporanKasus laporan = laporanRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Laporan tidak ditemukan"));
        laporan.setStatus(status);
        if (catatan != null) {
            laporan.setCatatanGuruBK(catatan);
        }
        getAuthenticatedUser().ifPresent(laporan::setPenanggungJawab);
        return laporanRepo.save(laporan);
    }

    // --- LOGIKA KONSELING ---
    public SesiKonseling ajukanKonseling(SesiKonseling konseling) {
        getAuthenticatedUser().ifPresent(konseling::setSiswa);
        konseling.setStatus(StatusKonseling.MENUNGGU_KONFIRMASI);
        return konselingRepo.save(konseling);
    }

    public List<List<SesiKonseling>> getKonselingList() {
        return List.of(konselingRepo.findAll());
    }

    public List<SesiKonseling> getSemuaKonseling() {
        return konselingRepo.findAll();
    }

    public List<SesiKonseling> getKonselingSaya() {
        return getAuthenticatedUser()
                .map(konselingRepo::findBySiswa)
                .orElse(List.of());
    }

    public SesiKonseling updateStatusKonseling(Long id, StatusKonseling status) {
        SesiKonseling konseling = konselingRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Sesi tidak ditemukan"));
        konseling.setStatus(status);
        getAuthenticatedUser().ifPresent(konseling::setGuruBk);
        return konselingRepo.save(konseling);
    }
}