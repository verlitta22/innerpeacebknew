package com.innerpeacebk.innerpeacebk.views;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.theme.lumo.LumoUtility;

public class MainLayout extends AppLayout {

    public MainLayout() {
        createHeader();
        createDrawer();
    }

    private void createHeader() {
        DrawerToggle toggle = new DrawerToggle();

        H1 title = new H1("InnerPeaceBK");
        title.getStyle()
                .set("font-size", "18px")
                .set("margin", "0")
                .set("color", "#2563eb")
                .set("font-weight", "800");

        HorizontalLayout header = new HorizontalLayout(toggle, title);
        header.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
        header.setWidthFull();
        header.addClassNames(LumoUtility.Padding.Vertical.NONE, LumoUtility.Padding.Horizontal.MEDIUM);

        addToNavbar(header);
    }

    private void createDrawer() {
        VerticalLayout drawerLayout = new VerticalLayout();
        drawerLayout.setSizeFull();
        drawerLayout.setPadding(true);
        drawerLayout.setSpacing(true);

        // 1. App Sub Header
        HorizontalLayout subHeader = new HorizontalLayout();
        subHeader.setAlignItems(FlexComponent.Alignment.CENTER);

        Icon logoIcon = VaadinIcon.HEART.create();
        logoIcon.getStyle().set("color", "#2563eb").set("width", "20px").set("height", "20px");

        Span portalTitle = new Span("Portal Guru BK");
        portalTitle.getStyle()
                .set("font-weight", "700")
                .set("color", "#64748b")
                .set("font-size", "14px")
                .set("margin-left", "8px");

        subHeader.add(logoIcon, portalTitle);

        // 2. Navigation Menu
        SideNav nav = new SideNav();
        nav.setWidthFull();

        SideNavItem itemDashboard = new SideNavItem("Dashboard", GuruDashboardView.class);
        itemDashboard.setPrefixComponent(VaadinIcon.GRID_BIG.create());

        // --- MENU BARU: VERIFIKASI AKUN ---
        SideNavItem itemVerifikasi = new SideNavItem("Verifikasi Akun", AdminVerifikasiView.class);
        itemVerifikasi.setPrefixComponent(VaadinIcon.CHECK_CIRCLE_O.create());

        SideNavItem itemLaporan = new SideNavItem("Data Laporan Kasus", KelolaLaporanView.class);
        itemLaporan.setPrefixComponent(VaadinIcon.WARNING.create());

        SideNavItem itemKonsultasi = new SideNavItem("Data Konsultasi", ReportView.class);
        itemKonsultasi.setPrefixComponent(VaadinIcon.FILE_TEXT.create());

        SideNavItem itemSiswa = new SideNavItem("Data Siswa", DataSiswaView.class);
        itemSiswa.setPrefixComponent(VaadinIcon.USERS.create());

        SideNavItem itemStatistik = new SideNavItem("Statistik", StatistikView.class);
        itemStatistik.setPrefixComponent(VaadinIcon.BAR_CHART.create());

        SideNavItem itemKategori = new SideNavItem("Kategori Masalah", KategoriMasalahView.class);
        itemKategori.setPrefixComponent(VaadinIcon.COG.create());

        // Menambahkan menu verifikasi ke dalam sidebar
        nav.addItem(
            itemDashboard, 
            itemVerifikasi, 
            itemLaporan, 
            itemKonsultasi, 
            itemSiswa, 
            itemStatistik, 
            itemKategori
        );

        Scroller scroller = new Scroller(nav);
        scroller.setWidthFull();
        scroller.getStyle().set("flex-grow", "1"); // Area menu mengembang & scrollable

        // 3. Footer Sidebar (Profil + Tombol Logout Merah)
        VerticalLayout sidebarFooter = createSidebarFooter();

        drawerLayout.add(subHeader, scroller, sidebarFooter);
        addToDrawer(drawerLayout);
    }

    private VerticalLayout createSidebarFooter() {
        VerticalLayout footer = new VerticalLayout();
        footer.setPadding(false);
        footer.setSpacing(true);
        footer.setWidthFull();
        footer.getStyle()
                .set("margin-top", "auto") // Mengunci footer ke bagian paling bawah
                .set("padding-top", "16px")
                .set("border-top", "1px solid #f1f5f9");

        // Profile Section
        HorizontalLayout profileLayout = new HorizontalLayout();
        profileLayout.setAlignItems(FlexComponent.Alignment.CENTER);

        Div avatar = new Div();
        avatar.setText("RS");
        avatar.getStyle()
                .set("width", "42px")
                .set("height", "42px")
                .set("border-radius", "50%")
                .set("background-color", "#dbeafe")
                .set("color", "#2563eb")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("font-weight", "700")
                .set("font-size", "14px")
                .set("margin-right", "10px");

        VerticalLayout profileText = new VerticalLayout();
        profileText.setPadding(false);
        profileText.setSpacing(false);

        Span name = new Span("Dra. Rina Susanti, M.Pd");
        name.getStyle()
                .set("font-weight", "800")
                .set("color", "#0f172a")
                .set("font-size", "14px");

        Span role = new Span("Guru BK · SMKN 1 Contoh");
        role.getStyle()
                .set("color", "#94a3b8")
                .set("font-size", "12px");

        profileText.add(name, role);
        profileLayout.add(avatar, profileText);

        // Logout Button
        Button btnLogout = new Button("Logout", VaadinIcon.SIGN_OUT.create());
        btnLogout.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
        btnLogout.getStyle()
                .set("color", "#ef4444")
                .set("font-weight", "700")
                .set("cursor", "pointer")
                .set("padding", "0")
                .set("margin-top", "8px");

        btnLogout.addClickListener(e -> {
            getUI().ifPresent(ui -> ui.getPage().setLocation("/login"));
        });

        footer.add(profileLayout, btnLogout);
        return footer;
    }
}