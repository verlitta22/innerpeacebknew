package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.Laporan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaporanRepository extends JpaRepository<Laporan, Long> {
}