package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;
import com.innerpeacebk.innerpeacebk.repository.KonsultasiRepository; // Sesuaikan dengan repository konsultasi Anda jika ada
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;

@RolesAllowed("GURU_BK")
@Route(value = "report", layout = GuruDashboardView.class)
public class ReportView extends VerticalLayout {

    private final LaporanKasusRepository laporanRepository;

    public ReportView(LaporanKasusRepository laporanRepository) {
        this.laporanRepository = laporanRepository;
        setSizeFull();
        setPadding(true);
        setSpacing(true);
        getStyle().set("background-color", "#f9fafb");

        // Header Halaman
        H2 title = new H2("Report & Rekapitulasi Data");
        title.getStyle().set("margin-top", "0");

        // Filter Berdasarkan Periode (Bulan / Tahun)
        ComboBox<String> filterPeriode = new ComboBox<>("Periode Waktu");
        filterPeriode.setItems("Bulan Ini", "Tahun Ini", "Semua Waktu");
        filterPeriode.setValue("Bulan Ini");

        Button btnDownload = new Button("Unduh Laporan (PDF/Excel)", VaadinIcon.DOWNLOAD.create());
        btnDownload.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

        HorizontalLayout filterLayout = new HorizontalLayout(filterPeriode, btnDownload);
        filterLayout.setAlignItems(Alignment.BASELINE);

        // Container Kartu Statistik Ringkasan Report
        HorizontalLayout cardsLayout = new HorizontalLayout();
        cardsLayout.setWidthFull();
        cardsLayout.setSpacing(true);

        long totalLaporan = laporanRepository.count();

        cardsLayout.add(
            createReportCard("Total Laporan Masuk", String.valueOf(totalLaporan), "Dihitung dari database laporan"),
            createReportCard("Konsultasi Selesai", "0", "Berdasarkan sesi konseling"),
            createReportCard("Kasus Pending", "0", "Belum ditangani")
        );

        add(title, filterLayout, cardsLayout);
    }

    private Div createReportCard(String title, String value, String subtitle) {
        Div card = new Div();
        card.getStyle()
            .set("background", "white")
            .set("padding", "20px")
            .set("border-radius", "12px")
            .set("box-shadow", "0 1px 3px rgba(0,0,0,0.1)")
            .set("flex", "1");

        Span titleSpan = new Span(title);
        titleSpan.getStyle().set("color", "var(--lumo-secondary-text-color)").set("font-size", "14px");

        H2 valueH2 = new H2(value);
        valueH2.getStyle().set("margin", "10px 0 5px 0");

        Span subSpan = new Span(subtitle);
        subSpan.getStyle().set("color", "var(--lumo-tertiary-text-color)").set("font-size", "12px");

        card.add(titleSpan, valueH2, subSpan);
        return card;
    }
}