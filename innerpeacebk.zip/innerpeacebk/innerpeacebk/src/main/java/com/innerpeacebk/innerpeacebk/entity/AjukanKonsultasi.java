package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "consultations")
public class AjukanKonsultasi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String kode; // Untuk Tracking ID (misal: KNS-2025-059)

    @ManyToOne
    @JoinColumn(name = "siswa_id")
    private User siswa;

    private String kategori;
    private String topik; // Sebagai Judul Konsultasi
    
    @Column(name = "detail_masalah", length = 2000)
    private String detailMasalah;

    private String metode; // Tatap Muka / Online
    private String waktu; // Pagi / Siang / Setelah Jam Pelajaran
    
    @Column(name = "catatan_gurubk", length = 1000)
    private String catatanGurubk;

    private String status = "PENDING"; // PENDING, DIJADWALKAN, SELESAI, DITOLAK
    
    @Column(name = "tanggal_pengajuan")
    private LocalDateTime tanggalPengajuan = LocalDateTime.now();

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getKode() { return kode; }
    public void setKode(String kode) { this.kode = kode; }

    public User getSiswa() { return siswa; }
    public void setSiswa(User siswa) { this.siswa = siswa; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getTopik() { return topik; }
    public void setTopik(String topik) { this.topik = topik; }

    public String getDetailMasalah() { return detailMasalah; }
    public void setDetailMasalah(String detailMasalah) { this.detailMasalah = detailMasalah; }

    public String getMetode() { return metode; }
    public void setMetode(String metode) { this.metode = metode; }

    public String getWaktu() { return waktu; }
    public void setWaktu(String waktu) { this.waktu = waktu; }

    public String getCatatanGurubk() { return catatanGurubk; }
    public void setCatatanGurubk(String catatanGurubk) { this.catatanGurubk = catatanGurubk; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getTanggalPengajuan() { return tanggalPengajuan; }
    public void setTanggalPengajuan(LocalDateTime tanggalPengajuan) { this.tanggalPengajuan = tanggalPengajuan; }
}