package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;

@RolesAllowed("GURU_BK")
@Route(value = "laporan", layout = GuruDashboardView.class)
public class KelolaLaporanView extends VerticalLayout {

    private final Grid<LaporanKasus> grid = new Grid<>(LaporanKasus.class);
    private final LaporanKasusRepository repository;

    public KelolaLaporanView(LaporanKasusRepository repository) {
        this.repository = repository;
        setSizeFull();
        setPadding(true);

        configureGrid();
        add(grid);
        
        updateList();
    }

    private void configureGrid() {
        grid.setSizeFull();
        grid.removeAllColumns();

        grid.addColumn(LaporanKasus::getJudul).setHeader("Judul Kasus");
        
        // Pelapor selalu terlihat secara langsung
        grid.addColumn(l -> l.getPelapor() != null ? l.getPelapor().getUsername() : "N/A")
            .setHeader("Pelapor");
            
        grid.addColumn(LaporanKasus::getLokasi).setHeader("Lokasi");
        grid.addColumn(LaporanKasus::getStatus).setHeader("Status");
        grid.addColumn(LaporanKasus::getTanggalDibuat).setHeader("Tanggal Dibuat");
        
        grid.addComponentColumn(laporan -> {
            Button detailBtn = new Button("Detail", VaadinIcon.EYE.create());
            detailBtn.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
            detailBtn.addClickListener(e -> UI.getCurrent().navigate("laporan/detail/" + laporan.getId()));
            return detailBtn;
        }).setHeader("Aksi");
    }

    private void updateList() {
        grid.setItems(repository.findAll());
    }
}