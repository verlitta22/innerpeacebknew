package com.innerpeacebk.innerpeacebk.views;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.auth.AnonymousAllowed;

@Route("") // URL Utama: http://localhost:8080/
@PageTitle("InnerPeaceBK - Layanan Konsultasi BK Sekolah Digital")
@AnonymousAllowed
public class LandingView extends VerticalLayout {

    public LandingView() {
        setSpacing(false);
        setPadding(false);
        setWidthFull();
        getStyle().set("background-color", "#ffffff");
        getStyle().set("min-height", "100vh");
        getStyle().set("height", "auto");
        getStyle().set("overflow", "visible");

        // CSS Reset & Smooth Scroll
        UI.getCurrent().getPage().executeJs(
            "document.body.style.margin = '0';" +
            "document.body.style.padding = '0';" +
            "document.body.style.overflowX = 'hidden';" +
            "document.documentElement.style.scrollBehavior = 'smooth';"
        );

        add(
            createHeader(),
            createHeroSection(),
            createFiturSection(),
            createCaraKerjaSection(),
            createMengapaSection(),
            createFooter()
        );
    }

    // 1. NAVBAR / HEADER
    private Header createHeader() {
        Header header = new Header();
        header.setWidthFull();
        header.getStyle()
                .set("position", "sticky")
                .set("top", "0")
                .set("z-index", "1000")
                .set("background-color", "#ffffff")
                .set("box-shadow", "0 2px 8px rgba(0,0,0,0.05)");

        HorizontalLayout navContent = new HorizontalLayout();
        navContent.setWidthFull();
        navContent.setMaxWidth("1200px");
        navContent.setAlignItems(FlexComponent.Alignment.CENTER);
        navContent.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);
        navContent.getStyle().set("margin", "0 auto").set("padding", "15px 20px").set("box-sizing", "border-box");

        H2 logo = new H2("InnerPeaceBK");
        logo.getStyle().set("color", "#2563eb").set("margin", "0").set("font-weight", "700").set("font-size", "22px");

        HorizontalLayout menu = new HorizontalLayout();
        menu.setSpacing(true);
        menu.add(
            createNavLink("Beranda", "#hero"),
            createNavLink("Tentang", "#tentang"),
            createNavLink("Cara Kerja", "#cara-kerja"),
            createNavLink("Fitur", "#fitur"),
            createNavLink("Kontak", "#kontak")
        );

        Button loginBtn = new Button("Login", e -> UI.getCurrent().navigate(LoginView.class));
        loginBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);

        Button ajukanBtn = new Button("Ajukan Konsultasi", e -> UI.getCurrent().navigate(LoginView.class));
        ajukanBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        ajukanBtn.getStyle().set("background-color", "#2563eb");

        HorizontalLayout actions = new HorizontalLayout(loginBtn, ajukanBtn);
        actions.setAlignItems(FlexComponent.Alignment.CENTER);

        navContent.add(logo, menu, actions);
        header.add(navContent);
        return header;
    }

    private Anchor createNavLink(String text, String href) {
        Anchor link = new Anchor(href, text);
        link.getStyle()
                .set("color", "#4b5563")
                .set("text-decoration", "none")
                .set("font-weight", "500")
                .set("margin", "0 10px");
        return link;
    }

    // 2. HERO SECTION
    private Component createHeroSection() {
        HorizontalLayout hero = new HorizontalLayout();
        hero.setId("hero");
        hero.setWidthFull();
        hero.setMaxWidth("1200px");
        hero.getStyle()
                .set("margin", "40px auto")
                .set("padding", "40px 20px")
                .set("box-sizing", "border-box")
                .set("scroll-margin-top", "90px"); // <-- Mencegah tertutup Navbar saat diklik
        hero.setAlignItems(FlexComponent.Alignment.CENTER);

        // Kiri: Teks & Call to Action
        VerticalLayout left = new VerticalLayout();
        left.setSpacing(true);
        left.setPadding(false);

        Span tag = new Span("✓ Sistem Konseling Sekolah Digital");
        tag.getStyle()
                .set("background-color", "#eff6ff")
                .set("color", "#2563eb")
                .set("padding", "6px 14px")
                .set("border-radius", "20px")
                .set("font-size", "14px")
                .set("font-weight", "600");

        H1 heading = new H1("Layanan Konsultasi BK\nSekolah Secara Online");
        heading.getStyle().set("font-size", "42px").set("line-height", "1.2").set("color", "#1e293b");

        Paragraph subtext = new Paragraph("Sampaikan permasalahanmu dengan aman, nyaman, dan rahasia. Guru BK siap membantu setiap langkahmu.");
        subtext.getStyle().set("color", "#64748b").set("font-size", "18px").set("max-width", "500px");

        Button btnPrimary = new Button("Ajukan Konsultasi ->", e -> UI.getCurrent().navigate(LoginView.class));
        btnPrimary.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        btnPrimary.getStyle().set("background-color", "#2563eb").set("padding", "12px 24px");

        Button btnSecondary = new Button("Login", e -> UI.getCurrent().navigate(LoginView.class));
        btnSecondary.addThemeVariants(ButtonVariant.LUMO_CONTRAST);

        HorizontalLayout ctaGroup = new HorizontalLayout(btnPrimary, btnSecondary);

        HorizontalLayout badges = new HorizontalLayout(
                new Span("✓ Aman & Rahasia"),
                new Span("✓ Gratis untuk Siswa"),
                new Span("✓ 24/7 Tersedia")
        );
        badges.getStyle().set("color", "#64748b").set("font-size", "14px").set("margin-top", "20px");

        left.add(tag, heading, subtext, ctaGroup, badges);

        // Kanan: Preview Chat & Statistik
        VerticalLayout rightCard = new VerticalLayout();
        rightCard.setWidthFull();
        rightCard.getStyle()
                .set("background-color", "#eff6ff")
                .set("border-radius", "24px")
                .set("padding", "24px")
                .set("box-sizing", "border-box")
                .set("min-width", "0")
                .set("overflow", "hidden");

        // Chat Box Component
        Div chatBox = new Div();
        chatBox.setWidthFull();
        chatBox.getStyle()
                .set("background-color", "#ffffff")
                .set("border-radius", "16px")
                .set("padding", "20px")
                .set("box-sizing", "border-box")
                .set("box-shadow", "0 10px 25px rgba(0,0,0,0.05)")
                .set("margin-bottom", "16px");

        Div headerChat = new Div(new Span("👤 Guru BK Rina"), new Span(" • Online sekarang"));
        headerChat.getStyle()
                .set("font-weight", "bold")
                .set("color", "#1e293b")
                .set("margin-bottom", "16px")
                .set("font-size", "15px");

        Div msg1 = new Div(new Text("Halo! Ada yang bisa saya bantu?"));
        msg1.getStyle()
                .set("background", "#f1f5f9")
                .set("color", "#334155")
                .set("padding", "10px 14px")
                .set("border-radius", "12px")
                .set("margin-bottom", "10px")
                .set("font-size", "14px")
                .set("max-width", "80%");

        Div msg2Wrapper = new Div();
        msg2Wrapper.getStyle().set("display", "flex").set("justify-content", "flex-end").set("margin-bottom", "10px");
        
        Div msg2 = new Div(new Text("Saya ingin konsultasi soal masalah akademik..."));
        msg2.getStyle()
                .set("background", "#2563eb")
                .set("color", "white")
                .set("padding", "10px 14px")
                .set("border-radius", "12px")
                .set("font-size", "14px")
                .set("max-width", "80%");
        msg2Wrapper.add(msg2);

        Div msg3 = new Div(new Text("Tentu, saya siap membantu kamu 😊"));
        msg3.getStyle()
                .set("background", "#f1f5f9")
                .set("color", "#334155")
                .set("padding", "10px 14px")
                .set("border-radius", "12px")
                .set("font-size", "14px")
                .set("max-width", "80%");

        chatBox.add(headerChat, msg1, msg2Wrapper, msg3);

        // Stats Grid Component
        Div stats = new Div();
        stats.setWidthFull();
        stats.getStyle()
                .set("display", "flex")
                .set("gap", "12px")
                .set("box-sizing", "border-box");

        Div stat1 = new Div();
        stat1.getStyle()
                .set("flex", "1")
                .set("background", "white")
                .set("padding", "16px")
                .set("border-radius", "16px")
                .set("box-sizing", "border-box")
                .set("box-shadow", "0 4px 12px rgba(0,0,0,0.03)");
        H2 val1 = new H2("127");
        val1.getStyle().set("margin", "0").set("color", "#1e293b");
        Span lbl1 = new Span("Konsultasi Selesai");
        lbl1.getStyle().set("color", "#64748b").set("font-size", "13px");
        stat1.add(val1, lbl1);

        Div stat2 = new Div();
        stat2.getStyle()
                .set("flex", "1")
                .set("background", "white")
                .set("padding", "16px")
                .set("border-radius", "16px")
                .set("box-sizing", "border-box")
                .set("box-shadow", "0 4px 12px rgba(0,0,0,0.03)");
        H2 val2 = new H2("98%");
        val2.getStyle().set("margin", "0").set("color", "#1e293b");
        Span lbl2 = new Span("Tingkat Kepuasan");
        lbl2.getStyle().set("color", "#64748b").set("font-size", "13px");
        stat2.add(val2, lbl2);

        stats.add(stat1, stat2);

        rightCard.add(chatBox, stats);

        hero.add(left, rightCard);
        hero.setFlexGrow(1, left);
        hero.setFlexGrow(1, rightCard);

        return hero;
    }

    // 3. FITUR UNGGULAN SECTION
    private Component createFiturSection() {
        VerticalLayout section = new VerticalLayout();
        section.setId("fitur");
        section.setWidthFull();
        section.setMaxWidth("1200px");
        section.getStyle()
                .set("margin", "60px auto")
                .set("padding", "20px")
                .set("box-sizing", "border-box")
                .set("scroll-margin-top", "90px"); // <-- Mencegah tertutup Navbar saat diklik
        section.setAlignItems(FlexComponent.Alignment.CENTER);

        H2 title = new H2("Fitur Unggulan InnerPeaceBK");
        Paragraph sub = new Paragraph("Semua yang kamu butuhkan untuk proses konseling yang lebih efektif dan terorganisir.");
        sub.getStyle().set("color", "#64748b");

        HorizontalLayout grid1 = new HorizontalLayout();
        grid1.setWidthFull();
        grid1.setSpacing(true);
        grid1.add(
            createFeatureCard(VaadinIcon.CHAT, "Konsultasi Online", "Ajukan permasalahanmu kapan saja dan di mana saja secara aman dan mudah."),
            createFeatureCard(VaadinIcon.TIME_BACKWARD, "Riwayat Konsultasi", "Pantau semua riwayat pengajuan konsultasi dengan mudah dalam satu tempat."),
            createFeatureCard(VaadinIcon.TRENDING_UP, "Tracking Status", "Lacak perkembangan konsultasimu secara real-time dengan tracking ID unik.")
        );

        HorizontalLayout grid2 = new HorizontalLayout();
        grid2.setWidthFull();
        grid2.setSpacing(true);
        grid2.add(
            createFeatureCard(VaadinIcon.CALENDAR, "Jadwal Konseling", "Lihat dan kelola jadwal sesi konseling langsung dari dashboard-mu."),
            createFeatureCard(VaadinIcon.SHIELD, "Privasi Terjamin", "Data konsultasimu hanya dapat diakses oleh Guru BK yang berwenang."),
            createFeatureCard(VaadinIcon.STAR, "Mudah Digunakan", "Antarmuka yang bersih dan intuitif untuk siswa maupun Guru BK.")
        );

        section.add(title, sub, grid1, grid2);
        return section;
    }

    private Div createFeatureCard(VaadinIcon iconType, String title, String desc) {
        Div card = new Div();
        card.setWidthFull();
        card.getStyle()
                .set("background", "#ffffff")
                .set("border", "1px solid #e2e8f0")
                .set("border-radius", "16px")
                .set("padding", "24px")
                .set("box-sizing", "border-box")
                .set("box-shadow", "0 4px 6px -1px rgba(0, 0, 0, 0.05)");

        com.vaadin.flow.component.icon.Icon icon = iconType.create();
        icon.getStyle().set("color", "#2563eb").set("margin-bottom", "12px");

        H3 h3 = new H3(title);
        h3.getStyle().set("font-size", "18px").set("margin", "10px 0");

        Paragraph p = new Paragraph(desc);
        p.getStyle().set("color", "#64748b").set("font-size", "14px");

        card.add(icon, h3, p);
        return card;
    }

    // 4. CARA KERJA SECTION
    private Component createCaraKerjaSection() {
        VerticalLayout section = new VerticalLayout();
        section.setId("cara-kerja");
        section.setWidthFull();
        section.getStyle()
                .set("background-color", "#f8fafc")
                .set("padding", "60px 20px")
                .set("box-sizing", "border-box")
                .set("scroll-margin-top", "90px"); // <-- Mencegah tertutup Navbar saat diklik
        section.setAlignItems(FlexComponent.Alignment.CENTER);

        H2 title = new H2("Cara Kerja InnerPeaceBK");
        Paragraph sub = new Paragraph("Proses konsultasi yang mudah hanya dalam 5 langkah sederhana.");
        sub.getStyle().set("color", "#64748b");

        HorizontalLayout steps = new HorizontalLayout();
        steps.setMaxWidth("1200px");
        steps.setWidthFull();
        steps.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);

        steps.add(
            createStepCard("01", "Login", "Masuk menggunakan akun siswa atau Guru BK yang telah terdaftar."),
            createStepCard("02", "Ajukan Konsultasi", "Isi formulir konsultasi dengan lengkap dan jelas."),
            createStepCard("03", "Guru BK Meninjau", "Guru BK akan meninjau dan memproses pengajuan konsultasimu."),
            createStepCard("04", "Jadwal Konseling", "Guru BK menjadwalkan sesi konseling yang sesuai."),
            createStepCard("05", "Konsultasi Selesai", "Sesi konseling berlangsung dan catatan tersimpan dengan aman.")
        );

        section.add(title, sub, steps);
        return section;
    }

    private Div createStepCard(String stepNum, String title, String desc) {
        Div card = new Div();
        card.getStyle().set("text-align", "center").set("max-width", "200px");

        Span num = new Span(stepNum);
        num.getStyle()
                .set("background", "#2563eb")
                .set("color", "white")
                .set("border-radius", "12px")
                .set("padding", "12px 18px")
                .set("font-weight", "bold")
                .set("display", "inline-block")
                .set("margin-bottom", "15px");

        H4 h4 = new H4(title);
        h4.getStyle().set("margin", "8px 0");

        Paragraph p = new Paragraph(desc);
        p.getStyle().set("color", "#64748b").set("font-size", "13px");

        card.add(num, h4, p);
        return card;
    }

    // 5. MENGAPA SECTION
    private Component createMengapaSection() {
        VerticalLayout section = new VerticalLayout();
        section.setId("tentang");
        section.setWidthFull();
        section.getStyle()
                .set("background-color", "#2563eb")
                .set("color", "white")
                .set("padding", "60px 20px")
                .set("box-sizing", "border-box")
                .set("scroll-margin-top", "90px"); // <-- Mencegah tertutup Navbar saat diklik
        section.setAlignItems(FlexComponent.Alignment.CENTER);

        H2 title = new H2("Mengapa Memilih InnerPeaceBK?");
        title.getStyle().set("color", "white");

        Paragraph sub = new Paragraph("Platform yang dirancang khusus untuk memudahkan proses konseling di lingkungan sekolah.");
        sub.getStyle().set("color", "#bfdbfe");

        HorizontalLayout cards = new HorizontalLayout();
        cards.setMaxWidth("1000px");
        cards.setWidthFull();
        cards.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);

        cards.add(
            createBlueBadge("🔒 Aman"),
            createBlueBadge("⚡ Cepat"),
            createBlueBadge("📖 Mudah Digunakan"),
            createBlueBadge("🛡️ Data Aman"),
            createBlueBadge("👥 Membantu Guru BK")
        );

        section.add(title, sub, cards);
        return section;
    }

    private Div createBlueBadge(String text) {
        Div b = new Div(new Text(text));
        b.getStyle()
                .set("background", "rgba(255, 255, 255, 0.15)")
                .set("border", "1px solid rgba(255, 255, 255, 0.3)")
                .set("border-radius", "12px")
                .set("padding", "20px")
                .set("min-width", "140px")
                .set("text-align", "center")
                .set("font-weight", "bold");
        return b;
    }

    // 6. FOOTER
    private Component createFooter() {
        Footer footer = new Footer();
        footer.setId("kontak");
        footer.setWidthFull();
        footer.getStyle()
                .set("background-color", "#0f172a")
                .set("color", "#94a3b8")
                .set("padding", "40px 20px 20px 20px")
                .set("box-sizing", "border-box")
                .set("scroll-margin-top", "90px"); // <-- Mencegah tertutup Navbar saat diklik

        VerticalLayout content = new VerticalLayout();
        content.setMaxWidth("1200px");
        content.getStyle().set("margin", "0 auto");

        HorizontalLayout top = new HorizontalLayout();
        top.setWidthFull();
        top.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);

        Div col1 = new Div();
        H3 fLogo = new H3("InnerPeaceBK");
        fLogo.getStyle().set("color", "white");
        col1.add(fLogo, new Paragraph("Sistem Layanan Konseling dan Laporan BK Sekolah yang modern dan terpercaya."));

        Div col2 = new Div();
        H4 h2 = new H4("Kontak Sekolah");
        h2.getStyle().set("color", "white");
        col2.add(h2, new Paragraph("✉ bk@smk24jakarta.sch.id"), new Paragraph("📞 (021) 5551234"), new Paragraph("📍 Jakarta, Indonesia"));

        top.add(col1, col2);

        Div bottom = new Div(new Paragraph("© 2026 InnerPeaceBK. Semua hak dilindungi. Dikembangkan untuk kemajuan pendidikan Indonesia."));
        bottom.getStyle().set("border-top", "1px solid #1e293b").set("margin-top", "20px").set("padding-top", "20px").set("text-align", "center").set("width", "100%");

        content.add(top, bottom);
        footer.add(content);
        return footer;
    }
}