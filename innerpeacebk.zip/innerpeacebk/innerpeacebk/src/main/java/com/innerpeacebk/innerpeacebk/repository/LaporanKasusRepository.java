package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.entity.StatusKasus;
import com.innerpeacebk.innerpeacebk.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LaporanKasusRepository extends JpaRepository<LaporanKasus, Long> {
    
    // Mencari laporan berdasarkan objek User pelapor
    List<LaporanKasus> findByPelapor(User pelapor);

    // Atau jika ingin mencari berdasarkan ID pelapor secara langsung:
    List<LaporanKasus> findByPelaporId(Long pelaporId);

    // Memperbaiki parameter status dari String menjadi enum StatusKasus
    long countByPelaporIdAndStatus(Long pelaporId, StatusKasus status);
}