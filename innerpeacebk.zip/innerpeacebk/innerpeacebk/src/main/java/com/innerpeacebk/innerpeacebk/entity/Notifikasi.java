package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifikasi")
public class Notifikasi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String pesan;
    private LocalDateTime tanggal;
    private boolean dibaca;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User siswa; // Menggunakan nama 'siswa'

    // Constructor Kosong Wajib untuk JPA
    public Notifikasi() {
    }

    // --- Getter dan Setter ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPesan() {
        return pesan;
    }

    public void setPesan(String pesan) {
        this.pesan = pesan;
    }

    public LocalDateTime getTanggal() {
        return tanggal;
    }

    public void setTanggal(LocalDateTime tanggal) {
        this.tanggal = tanggal;
    }

    public boolean isDibaca() {
        return dibaca;
    }

    public void setDibaca(boolean dibaca) {
        this.dibaca = dibaca;
    }

    public User getSiswa() {
        return siswa;
    }

    public void setSiswa(User siswa) {
        this.siswa = siswa;
    }
}