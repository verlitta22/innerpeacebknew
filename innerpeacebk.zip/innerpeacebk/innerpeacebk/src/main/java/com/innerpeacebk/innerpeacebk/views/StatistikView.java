package com.innerpeacebk.innerpeacebk.views;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.PermitAll;

import java.util.ArrayList;
import java.util.List;

@Route(value = "statistik", layout = MainLayout.class)
@PageTitle("Statistik & Analitik | InnerPeaceBK")
@PermitAll
public class StatistikView extends VerticalLayout {

    // DTO untuk Ringkasan Bulanan
    public static class RingkasanBulanModel {
        private String bulan;
        private int konsultasi;
        private int laporan;
        private int selesai;
        private int dalamProses;
        private double tingkatPenyelesaian; // Nilai persentase misal 83, 89, dll.

        public RingkasanBulanModel(String bulan, int konsultasi, int laporan, int selesai, int dalamProses, double tingkatPenyelesaian) {
            this.bulan = bulan;
            this.konsultasi = konsultasi;
            this.laporan = laporan;
            this.selesai = selesai;
            this.dalamProses = dalamProses;
            this.tingkatPenyelesaian = tingkatPenyelesaian;
        }

        public String getBulan() { return bulan; }
        public int getKonsultasi() { return konsultasi; }
        public int getLaporan() { return laporan; }
        public int getSelesai() { return selesai; }
        public int getDalamProses() { return dalamProses; }
        public double getTingkatPenyelesaian() { return tingkatPenyelesaian; }
    }

    public StatistikView() {
        setSizeFull();
        setPadding(true);
        setSpacing(true);
        getStyle().set("background-color", "#f8fafc");

        // 1. Header Section
        add(createHeaderSection());

        // 2. Metrics Cards (6 Kartu Statistik Top)
        add(createMetricsGrid());

        // 3. Row 1: Tren Konsultasi & Laporan (Line Chart Place) + Kategori Terbanyak
        add(createRow1Section());

        // 4. Row 2: Konsultasi & Laporan per Kelas (Bar Chart Place) + Kelas Terbanyak
        add(createRow2Section());

        // 5. Row 3: Kategori Laporan Kasus (Pie Chart Place) + Status Konsultasi (Donut Chart)
        add(createRow3Section());

        // 6. Row 4: Tabel Ringkasan Bulanan
        add(createRingkasanBulananCard());
    }

    private VerticalLayout createHeaderSection() {
        VerticalLayout headerLayout = new VerticalLayout();
        headerLayout.setPadding(false);
        headerLayout.setSpacing(false);

        H2 title = new H2("Statistik & Analitik");
        title.getStyle()
                .set("margin", "0")
                .set("font-size", "24px")
                .set("font-weight", "800")
                .set("color", "#0f172a");

        Paragraph subtitle = new Paragraph("Data konsultasi dan laporan kasus sekolah — Januari s/d Juli 2025.");
        subtitle.getStyle()
                .set("margin", "4px 0 0 0")
                .set("color", "#64748b")
                .set("font-size", "14px");

        headerLayout.add(title, subtitle);
        return headerLayout;
    }

    // --- 1. Top Metrics Cards ---
    private HorizontalLayout createMetricsGrid() {
        HorizontalLayout layout = new HorizontalLayout();
        layout.setWidthFull();
        layout.setSpacing(true);

        layout.add(
                createMetricCard(VaadinIcon.BAR_CHART.create(), "#eff6ff", "#2563eb", "140", "Total Konsultasi Tahun Ini"),
                createMetricCard(VaadinIcon.EXCLAMATION_CIRCLE_O.create(), "#fef2f2", "#ef4444", "63", "Total Laporan Tahun Ini"),
                createMetricCard(VaadinIcon.TRENDING_UP.create(), "#f0fdf4", "#16a34a", "79%", "Tingkat Penyelesaian"),
                createMetricCard(VaadinIcon.CHECK_CIRCLE_O.create(), "#faf5ff", "#9333ea", "85%", "Laporan Diselesaikan"),
                createMetricCard(VaadinIcon.CALENDAR.create(), "#eff6ff", "#2563eb", "25", "Konsultasi Bulan Ini"),
                createMetricCard(VaadinIcon.USERS.create(), "#fff7ed", "#ea580c", "247", "Siswa Aktif")
        );

        return layout;
    }

    private VerticalLayout createMetricCard(Icon icon, String bgColor, String iconColor, String value, String label) {
        VerticalLayout card = new VerticalLayout();
        card.setPadding(true);
        card.setSpacing(false);
        card.setWidthFull();
        card.getStyle()
                .set("background-color", "#ffffff")
                .set("border-radius", "16px")
                .set("border", "1px solid #f1f5f9")
                .set("box-shadow", "0 1px 3px rgba(0,0,0,0.02)");

        Div iconWrapper = new Div();
        iconWrapper.getStyle()
                .set("width", "36px")
                .set("height", "36px")
                .set("border-radius", "10px")
                .set("background-color", bgColor)
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("margin-bottom", "12px");

        icon.getStyle().set("color", iconColor).set("width", "18px").set("height", "18px");
        iconWrapper.add(icon);

        H3 valText = new H3(value);
        valText.getStyle().set("margin", "0").set("font-size", "22px").set("font-weight", "800").set("color", "#0f172a");

        Span labelText = new Span(label);
        labelText.getStyle().set("font-size", "11px").set("color", "#64748b").set("font-weight", "500").set("margin-top", "4px");

        card.add(iconWrapper, valText, labelText);
        return card;
    }

    // --- 2. Row 1: Tren Chart & Kategori Terbanyak ---
    private HorizontalLayout createRow1Section() {
        HorizontalLayout row = new HorizontalLayout();
        row.setWidthFull();
        row.setSpacing(true);

        // Kiri: Tren Konsultasi & Laporan
        VerticalLayout trenCard = new VerticalLayout();
        trenCard.setWidth("68%");
        trenCard.setPadding(true);
        trenCard.getStyle().set("background-color", "#ffffff").set("border-radius", "16px").set("border", "1px solid #f1f5f9");

        H3 title = new H3("Tren Konsultasi & Laporan");
        title.getStyle().set("margin", "0").set("font-size", "16px").set("font-weight", "700");
        Paragraph sub = new Paragraph("Jumlah masuk per bulan — 2025");
        sub.getStyle().set("margin", "2px 0 16px 0").set("font-size", "12px").set("color", "#94a3b8");

        // Canvas / Container Visual Grafik Line Chart
        Div chartContainer = new Div();
        chartContainer.setWidthFull();
        chartContainer.setHeight("220px");
        chartContainer.getStyle()
                .set("border-bottom", "1px dashed #e2e8f0")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("background", "linear-gradient(180deg, rgba(241,245,249,0.3) 0%, rgba(255,255,255,1) 100%)");

        Span chartPlaceholder = new Span("[ Graphic Chart Canvas: Tren Line Chart ]");
        chartPlaceholder.getStyle().set("color", "#cbd5e1").set("font-size", "13px");
        chartContainer.add(chartPlaceholder);

        // Legend Bottom
        HorizontalLayout legend = new HorizontalLayout();
        legend.setSpacing(true);
        legend.getStyle().set("margin-top", "12px");

        Span legKonsultasi = new Span("— Konsultasi");
        legKonsultasi.getStyle().set("color", "#2563eb").set("font-size", "13px").set("font-weight", "600");

        Span legLaporan = new Span("— Laporan Kasus");
        legLaporan.getStyle().set("color", "#ef4444").set("font-size", "13px").set("font-weight", "600");

        legend.add(legKonsultasi, legLaporan);
        trenCard.add(title, sub, chartContainer, legend);

        // Kanan: Kategori Terbanyak
        VerticalLayout katCard = new VerticalLayout();
        katCard.setWidth("32%");
        katCard.setPadding(true);
        katCard.getStyle().set("background-color", "#ffffff").set("border-radius", "16px").set("border", "1px solid #f1f5f9");

        H3 katTitle = new H3("Kategori Terbanyak");
        katTitle.getStyle().set("margin", "0").set("font-size", "16px").set("font-weight", "700");
        Paragraph katSub = new Paragraph("Berdasarkan jumlah konsultasi");
        katSub.getStyle().set("margin", "2px 0 16px 0").set("font-size", "12px").set("color", "#94a3b8");

        katCard.add(
                katTitle, katSub,
                createBarProgressItem("Akademik", "35", 90, "#2563eb"),
                createBarProgressItem("Pertemanan", "22", 65, "#a855f7"),
                createBarProgressItem("Keluarga", "18", 50, "#ea580c"),
                createBarProgressItem("Mental", "12", 35, "#ef4444"),
                createBarProgressItem("Karier", "8", 20, "#16a34a")
        );

        row.add(trenCard, katCard);
        return row;
    }

    private VerticalLayout createBarProgressItem(String label, String count, double percent, String color) {
        VerticalLayout item = new VerticalLayout();
        item.setPadding(false);
        item.setSpacing(false);
        item.getStyle().set("margin-bottom", "12px");

        HorizontalLayout header = new HorizontalLayout();
        header.setWidthFull();
        header.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);

        Span lbl = new Span(label);
        lbl.getStyle().set("font-size", "13px").set("font-weight", "600").set("color", "#334155");

        Span val = new Span(count);
        val.getStyle().set("font-size", "13px").set("font-weight", "700").set("color", "#0f172a");

        header.add(lbl, val);

        ProgressBar pb = new ProgressBar();
        pb.setValue(percent / 100.0);
        pb.getStyle().set("height", "6px").set("border-radius", "4px");

        item.add(header, pb);
        return item;
    }

    // --- 3. Row 2: Bar Chart Kelas & Kelas Terbanyak ---
    private HorizontalLayout createRow2Section() {
        HorizontalLayout row = new HorizontalLayout();
        row.setWidthFull();
        row.setSpacing(true);

        // Kiri: Konsultasi & Laporan per Kelas
        VerticalLayout kelasCard = new VerticalLayout();
        kelasCard.setWidth("68%");
        kelasCard.setPadding(true);
        kelasCard.getStyle().set("background-color", "#ffffff").set("border-radius", "16px").set("border", "1px solid #f1f5f9");

        H3 title = new H3("Konsultasi & Laporan per Kelas");
        title.getStyle().set("margin", "0").set("font-size", "16px").set("font-weight", "700");
        Paragraph sub = new Paragraph("Distribusi berdasarkan kelas");
        sub.getStyle().set("margin", "2px 0 16px 0").set("font-size", "12px").set("color", "#94a3b8");

        Div chartContainer = new Div();
        chartContainer.setWidthFull();
        chartContainer.setHeight("200px");
        chartContainer.getStyle()
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("border-bottom", "1px dashed #e2e8f0");

        Span placeholder = new Span("[ Grouped Bar Chart Canvas: Kelas X, XI, XII ]");
        placeholder.getStyle().set("color", "#cbd5e1").set("font-size", "13px");
        chartContainer.add(placeholder);

        kelasCard.add(title, sub, chartContainer);

        // Kanan: Kelas Terbanyak Rank
        VerticalLayout rankCard = new VerticalLayout();
        rankCard.setWidth("32%");
        rankCard.setPadding(true);
        rankCard.getStyle().set("background-color", "#ffffff").set("border-radius", "16px").set("border", "1px solid #f1f5f9");

        H3 rTitle = new H3("Kelas Terbanyak");
        rTitle.getStyle().set("margin", "0").set("font-size", "16px").set("font-weight", "700");
        Paragraph rSub = new Paragraph("Berdasarkan total konsultasi");
        rSub.getStyle().set("margin", "2px 0 16px 0").set("font-size", "12px").set("color", "#94a3b8");

        rankCard.add(
                rTitle, rSub,
                createRankItem("1", "XII RPL", "32"),
                createRankItem("2", "XI RPL", "28"),
                createRankItem("3", "X RPL", "28"),
                createRankItem("4", "XII TKJ", "26"),
                createRankItem("5", "XI TKJ", "22")
        );

        row.add(kelasCard, rankCard);
        return row;
    }

    private HorizontalLayout createRankItem(String no, String kelasName, String count) {
        HorizontalLayout item = new HorizontalLayout();
        item.setWidthFull();
        item.setAlignItems(FlexComponent.Alignment.CENTER);
        item.getStyle().set("margin-bottom", "8px");

        Div badgeNo = new Div();
        badgeNo.setText(no);
        badgeNo.getStyle()
                .set("width", "24px")
                .set("height", "24px")
                .set("border-radius", "6px")
                .set("background-color", "#dbeafe")
                .set("color", "#2563eb")
                .set("font-size", "12px")
                .set("font-weight", "700")
                .set("display", "flex")
                .set("align-items", "center")
                .set("justify-content", "center")
                .set("margin-right", "8px");

        Span name = new Span(kelasName);
        name.getStyle().set("font-size", "13px").set("font-weight", "600").set("color", "#334155");

        Span val = new Span(count);
        val.getStyle().set("font-size", "13px").set("font-weight", "700").set("color", "#0f172a").set("margin-left", "auto");

        item.add(badgeNo, name, val);
        return item;
    }

    // --- 4. Row 3: Pie Chart & Donut Chart Status ---
    private HorizontalLayout createRow3Section() {
        HorizontalLayout row = new HorizontalLayout();
        row.setWidthFull();
        row.setSpacing(true);

        // Kategori Laporan Kasus (Pie Chart)
        VerticalLayout pieCard = new VerticalLayout();
        pieCard.setWidth("50%");
        pieCard.setPadding(true);
        pieCard.getStyle().set("background-color", "#ffffff").set("border-radius", "16px").set("border", "1px solid #f1f5f9");

        H3 title1 = new H3("Kategori Laporan Kasus");
        title1.getStyle().set("margin", "0").set("font-size", "16px").set("font-weight", "700");
        Paragraph sub1 = new Paragraph("Distribusi laporan berdasarkan kategori");
        sub1.getStyle().set("margin", "2px 0 16px 0").set("font-size", "12px").set("color", "#94a3b8");

        HorizontalLayout content1 = new HorizontalLayout();
        content1.setWidthFull();
        content1.setAlignItems(FlexComponent.Alignment.CENTER);

        Div piePlaceholder = new Div(new Span("[ Pie Chart ]"));
        piePlaceholder.getStyle().set("width", "140px").set("height", "140px").set("border-radius", "50%").set("background", "#fee2e2").set("display", "flex").set("align-items", "center").set("justify-content", "center");

        VerticalLayout legend1 = new VerticalLayout();
        legend1.setSpacing(false);
        legend1.add(
                createLegendPercentItem("• Bullying", "42%", "#dc2626"),
                createLegendPercentItem("• Mental", "28%", "#a855f7"),
                createLegendPercentItem("• Keluarga", "18%", "#ea580c"),
                createLegendPercentItem("• Pertemanan", "12%", "#2563eb")
        );

        content1.add(piePlaceholder, legend1);
        pieCard.add(title1, sub1, content1);

        // Status Konsultasi (Donut Chart)
        VerticalLayout donutCard = new VerticalLayout();
        donutCard.setWidth("50%");
        donutCard.setPadding(true);
        donutCard.getStyle().set("background-color", "#ffffff").set("border-radius", "16px").set("border", "1px solid #f1f5f9");

        H3 title2 = new H3("Status Konsultasi");
        title2.getStyle().set("margin", "0").set("font-size", "16px").set("font-weight", "700");
        Paragraph sub2 = new Paragraph("Distribusi status seluruh konsultasi");
        sub2.getStyle().set("margin", "2px 0 16px 0").set("font-size", "12px").set("color", "#94a3b8");

        HorizontalLayout content2 = new HorizontalLayout();
        content2.setWidthFull();
        content2.setAlignItems(FlexComponent.Alignment.CENTER);

        Div donutPlaceholder = new Div(new Span("[ Donut Chart ]"));
        donutPlaceholder.getStyle().set("width", "140px").set("height", "140px").set("border-radius", "50%").set("border", "16px solid #16a34a").set("display", "flex").set("align-items", "center").set("justify-content", "center");

        VerticalLayout legend2 = new VerticalLayout();
        legend2.setSpacing(false);
        legend2.add(
                createLegendPercentItem("• Selesai", "89", "#16a34a"),
                createLegendPercentItem("• Diproses", "15", "#2563eb"),
                createLegendPercentItem("• Dijadwalkan", "12", "#9333ea"),
                createLegendPercentItem("• Menunggu", "8", "#ea580c")
        );

        content2.add(donutPlaceholder, legend2);
        donutCard.add(title2, sub2, content2);

        row.add(pieCard, donutCard);
        return row;
    }

    private HorizontalLayout createLegendPercentItem(String label, String value, String color) {
        HorizontalLayout item = new HorizontalLayout();
        item.setWidthFull();
        item.setJustifyContentMode(FlexComponent.JustifyContentMode.BETWEEN);

        Span lbl = new Span(label);
        lbl.getStyle().set("font-size", "13px").set("color", color).set("font-weight", "600");

        Span val = new Span(value);
        val.getStyle().set("font-size", "13px").set("font-weight", "700").set("color", "#0f172a");

        item.add(lbl, val);
        return item;
    }

    // --- 5. Row 4: Ringkasan Bulanan Table ---
    private VerticalLayout createRingkasanBulananCard() {
        VerticalLayout card = new VerticalLayout();
        card.setPadding(true);
        card.setSpacing(true);
        card.getStyle()
                .set("background-color", "#ffffff")
                .set("border-radius", "16px")
                .set("border", "1px solid #f1f5f9")
                .set("margin-top", "8px");

        H3 title = new H3("Ringkasan Bulanan");
        title.getStyle().set("margin", "0").set("font-size", "18px").set("font-weight", "800").set("color", "#0f172a");

        Grid<RingkasanBulanModel> grid = new Grid<>(RingkasanBulanModel.class, false);
        grid.addThemeVariants(GridVariant.LUMO_NO_BORDER, GridVariant.LUMO_ROW_STRIPES);
        grid.setAllRowsVisible(true);

        grid.addColumn(RingkasanBulanModel::getBulan).setHeader("Bulan").setAutoWidth(true);

        grid.addColumn(new ComponentRenderer<>(item -> {
            Span span = new Span(String.valueOf(item.getKonsultasi()));
            span.getStyle().set("font-weight", "700").set("color", "#0f172a");
            return span;
        })).setHeader("Konsultasi").setAutoWidth(true);

        grid.addColumn(new ComponentRenderer<>(item -> {
            Span badge = new Span(String.valueOf(item.getLaporan()));
            badge.getStyle().set("color", "#dc2626").set("font-weight", "700").set("background-color", "#fee2e2").set("padding", "2px 10px").set("border-radius", "10px");
            return badge;
        })).setHeader("Laporan").setAutoWidth(true);

        grid.addColumn(new ComponentRenderer<>(item -> {
            Span badge = new Span(String.valueOf(item.getSelesai()));
            badge.getStyle().set("color", "#16a34a").set("font-weight", "700").set("background-color", "#dcfce7").set("padding", "2px 10px").set("border-radius", "10px");
            return badge;
        })).setHeader("Selesai").setAutoWidth(true);

        grid.addColumn(new ComponentRenderer<>(item -> {
            Span badge = new Span(String.valueOf(item.getDalamProses()));
            badge.getStyle().set("color", "#2563eb").set("font-weight", "700").set("background-color", "#dbeafe").set("padding", "2px 10px").set("border-radius", "10px");
            return badge;
        })).setHeader("Dalam Proses").setAutoWidth(true);

        grid.addColumn(new ComponentRenderer<>(item -> {
            HorizontalLayout progressWrapper = new HorizontalLayout();
            progressWrapper.setAlignItems(FlexComponent.Alignment.CENTER);

            ProgressBar pb = new ProgressBar();
            pb.setValue(item.getTingkatPenyelesaian() / 100.0);
            pb.setWidth("100px");

            Span pct = new Span((int) item.getTingkatPenyelesaian() + "%");
            pct.getStyle().set("font-weight", "700").set("font-size", "12px").set("color", "#334155").set("margin-left", "8px");

            progressWrapper.add(pb, pct);
            return progressWrapper;
        })).setHeader("Tingkat Penyelesaian").setAutoWidth(true);

        grid.setItems(getRingkasanData());
        card.add(title, grid);
        return card;
    }

    private List<RingkasanBulanModel> getRingkasanData() {
        List<RingkasanBulanModel> list = new ArrayList<>();
        list.add(new RingkasanBulanModel("Januari 2025", 12, 5, 10, 2, 83));
        list.add(new RingkasanBulanModel("Februari 2025", 18, 8, 16, 2, 89));
        list.add(new RingkasanBulanModel("Maret 2025", 15, 6, 13, 2, 87));
        list.add(new RingkasanBulanModel("April 2025", 22, 10, 19, 3, 86));
        list.add(new RingkasanBulanModel("Mei 2025", 28, 14, 22, 6, 79));
        list.add(new RingkasanBulanModel("Juni 2025", 20, 9, 18, 2, 90));
        list.add(new RingkasanBulanModel("Juli 2025", 25, 11, 12, 13, 48));
        return list;
    }
}