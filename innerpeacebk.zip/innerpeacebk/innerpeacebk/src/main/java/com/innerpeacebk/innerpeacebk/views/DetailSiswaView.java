package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

@RolesAllowed("GURU_BK")
@Route(value = "data-siswa/detail", layout = GuruDashboardView.class)
public class DetailSiswaView extends VerticalLayout implements HasUrlParameter<Long> {

    private final UserRepository userRepository;
    private User currentUser;

    private final H3 namaHeader = new H3();
    private final Span nisVal = new Span();
    private final Span kelasVal = new Span();
    private final Span usernameVal = new Span();
    private final Span kartuPelajarVal = new Span();

    @Autowired
    public DetailSiswaView(UserRepository userRepository) {
        this.userRepository = userRepository;
        setSizeFull();
        setPadding(true);
        setSpacing(true);

        buildLayout();
    }

    private void buildLayout() {
        Button backBtn = new Button(VaadinIcon.ARROW_LEFT.create(), e -> getUI().ifPresent(ui -> ui.navigate("siswa")));
        backBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);

        HorizontalLayout topBar = new HorizontalLayout(backBtn, namaHeader);
        topBar.setAlignItems(Alignment.CENTER);

        Div cardDataPribadi = new Div();
        cardDataPribadi.getStyle().set("background", "white").set("padding", "20px").set("border-radius", "12px");
        cardDataPribadi.add(new H4("Data Pribadi"), nisVal, kelasVal, usernameVal, kartuPelajarVal);

        // Tombol Aksi Verifikasi Akun Siswa menggunakan StatusAcc
        Button btnSetuju = new Button("Setujui Akun", VaadinIcon.CHECK.create(), e -> updateStatusAkun(User.StatusAcc.APPROVED));
        btnSetuju.addThemeVariants(ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_SUCCESS);

        Button btnTolak = new Button("Tolak Akun", VaadinIcon.CLOSE.create(), e -> updateStatusAkun(User.StatusAcc.REJECTED));
        btnTolak.addThemeVariants(ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_PRIMARY);

        HorizontalLayout actionLayout = new HorizontalLayout(btnSetuju, btnTolak);

        add(topBar, cardDataPribadi, actionLayout);
    }

    @Override
    public void setParameter(BeforeEvent event, Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            currentUser = optionalUser.get();
            populateData();
        } else {
            Notification.show("Data siswa tidak ditemukan!", 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
            event.forwardTo("siswa");
        }
    }

    private void populateData() {
        if (currentUser == null) return;
        namaHeader.setText(currentUser.getNamaLengkap() != null ? currentUser.getNamaLengkap() : "-");
        nisVal.setText("NISN / NIS: " + (currentUser.getNisn() != null ? currentUser.getNisn() : "-"));
        kelasVal.setText("Kelas: " + (currentUser.getKelas() != null ? currentUser.getKelas() : "-"));
        usernameVal.setText("Username: " + (currentUser.getUsername() != null ? currentUser.getUsername() : "-"));
        kartuPelajarVal.setText("File Kartu Pelajar: " + (currentUser.getKartuPelajarPath() != null ? currentUser.getKartuPelajarPath() : "Tidak ada file"));
    }

    private void updateStatusAkun(User.StatusAcc status) {
        if (currentUser != null) {
            currentUser.setStatus(status);
            userRepository.save(currentUser);
            Notification.show("Status akun berhasil diperbarui menjadi " + status, 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_SUCCESS);
            getUI().ifPresent(ui -> ui.navigate("siswa"));
        }
    }
}