package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;

@RolesAllowed("GURU_BK")
@Route(value = "siswa", layout = GuruDashboardView.class)
public class DataSiswaView extends VerticalLayout {

    private final Grid<User> grid = new Grid<>(User.class);
    private final UserRepository userRepository;

    public DataSiswaView(UserRepository userRepository) {
        this.userRepository = userRepository;
        setSizeFull();
        setPadding(true);

        configureGrid();
        add(grid);
        updateList();
    }

    private void configureGrid() {
        grid.setSizeFull();
        grid.removeAllColumns();

        grid.addColumn(User::getNamaLengkap).setHeader("Nama Siswa");
        grid.addColumn(User::getNisn).setHeader("NIS");
        grid.addColumn(User::getKelas).setHeader("Kelas");
        
        // Kolom Status dengan tampilan badge
        grid.addComponentColumn(user -> {
            String status = user.getStatus() != null ? user.getStatus().name() : "PENDING";
            Span statusBadge = new Span(status);
            
            // Memberikan gaya visual (Badge)
            statusBadge.getElement().setAttribute("theme", 
                status.equals("APPROVED") ? "badge success" : "badge contrast");
            
            return statusBadge;
        }).setHeader("Status Akun");

        // Kolom Aksi (Verifikasi & Detail)
        grid.addComponentColumn(user -> {
            HorizontalLayout actions = new HorizontalLayout();
            actions.setSpacing(true);

            // Tombol Verifikasi: Hanya muncul jika status PENDING
            if (user.getStatus() == User.StatusAcc.PENDING) {
                Button verifyBtn = new Button("Verifikasi", VaadinIcon.CHECK.create());
                verifyBtn.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_SUCCESS);
                verifyBtn.addClickListener(e -> {
                    user.setStatus(User.StatusAcc.APPROVED);
                    userRepository.save(user);
                    
                    Notification.show("Akun " + user.getNamaLengkap() + " telah diverifikasi.", 3000, Notification.Position.TOP_CENTER)
                                .addThemeVariants(NotificationVariant.LUMO_SUCCESS);
                    
                    updateList(); // Refresh data grid
                });
                actions.add(verifyBtn);
            }

            // Tombol Detail
            Button detailBtn = new Button("Detail", VaadinIcon.EYE.create());
            detailBtn.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
            detailBtn.addClickListener(e -> UI.getCurrent().navigate("data-siswa/detail/" + user.getId()));
            
            actions.add(detailBtn);
            return actions;
        }).setHeader("Aksi");
    }

    private void updateList() {
        // Mengambil semua user dengan role SISWA
        // Pastikan UserRepository memiliki method: List<User> findByRole(User.Role role);
        grid.setItems(userRepository.findByRole(User.Role.SISWA));
    }
}