package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.StreamResource;

import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.FileInputStream;

// Ditambahkan layout = MainLayout.class agar sidebar tetap tampil
@Route(value = "guru/verifikasi-siswa", layout = MainLayout.class)
@PageTitle("Verifikasi Siswa | Guru BK")
@RolesAllowed({"GURU_BK", "ADMIN"})
public class VerifikasiSiswaView extends VerticalLayout {

    private final UserRepository userRepository;
    private final Grid<User> grid = new Grid<>(User.class, false);

    @Autowired
    public VerifikasiSiswaView(UserRepository userRepository) {
        this.userRepository = userRepository;
        
        setSizeFull();
        setPadding(true);
        setSpacing(true);

        H2 title = new H2("Verifikasi Akun Siswa Baru");
        title.getStyle().set("margin-top", "0").set("color", "#0f172a");

        // Konfigurasi Kolom Grid
        grid.addColumn(User::getNisn).setHeader("NISN").setAutoWidth(true);
        grid.addColumn(User::getNamaLengkap).setHeader("Nama Lengkap").setAutoWidth(true);
        grid.addColumn(User::getUsername).setHeader("Username / Email").setAutoWidth(true);

        // Badge Status
        grid.addColumn(new ComponentRenderer<>(siswa -> {
            Span statusBadge = new Span(siswa.getStatus().name());
            statusBadge.getStyle()
                    .set("padding", "4px 10px")
                    .set("border-radius", "12px")
                    .set("font-size", "12px")
                    .set("font-weight", "700")
                    .set("background-color", "#fef3c7")
                    .set("color", "#d97706");
            return statusBadge;
        })).setHeader("Status").setAutoWidth(true);

        // Tombol Cek Kartu Pelajar
        grid.addComponentColumn(siswa -> {
            Button btnBukti = new Button("Lihat Kartu", VaadinIcon.EYE.create(), e -> showKartuPelajarDialog(siswa));
            btnBukti.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_SMALL);
            return btnBukti;
        }).setHeader("Bukti Identitas").setAutoWidth(true);

        // Tombol Aksi Verifikasi (Menggunakan HorizontalLayout agar sejajar dan rapi)
        grid.addComponentColumn(siswa -> {
            Button btnApprove = new Button("Setujui", VaadinIcon.CHECK.create(), e -> {
                siswa.setStatus(User.StatusAcc.APPROVED);
                userRepository.save(siswa);
                
                Notification notif = Notification.show("Akun " + siswa.getNamaLengkap() + " Berhasil Disetujui!");
                notif.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
                refreshGrid();
            });
            btnApprove.addThemeVariants(ButtonVariant.LUMO_SUCCESS, ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_SMALL);

            Button btnReject = new Button("Tolak", VaadinIcon.CLOSE.create(), e -> {
                siswa.setStatus(User.StatusAcc.REJECTED);
                userRepository.save(siswa);
                
                Notification notif = Notification.show("Akun " + siswa.getNamaLengkap() + " Ditolak!");
                notif.addThemeVariants(NotificationVariant.LUMO_ERROR);
                refreshGrid();
            });
            btnReject.addThemeVariants(ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_SMALL);

            HorizontalLayout actions = new HorizontalLayout(btnApprove, btnReject);
            actions.setSpacing(true);
            return actions;
        }).setHeader("Aksi").setAutoWidth(true);

        add(title, grid);
        refreshGrid();
    }

    private void refreshGrid() {
        // Menampilkan siswa yang berstatus PENDING
        grid.setItems(userRepository.findAll().stream()
                .filter(u -> u.getRole() == User.Role.SISWA && u.getStatus() == User.StatusAcc.PENDING)
                .toList());
    }

    private void showKartuPelajarDialog(User siswa) {
        Dialog dialog = new Dialog();
        dialog.setHeaderTitle("Kartu Pelajar - " + siswa.getNamaLengkap());
        dialog.setWidth("500px");

        String filePath = siswa.getKartuPelajarPath();

        // Validasi jika path null atau file tidak ditemukan di server
        if (filePath != null && !filePath.trim().isEmpty()) {
            File file = new File(filePath);

            if (file.exists()) {
                StreamResource resource = new StreamResource(file.getName(), () -> {
                    try {
                        return new FileInputStream(file);
                    } catch (Exception e) {
                        return null;
                    }
                });

                Image img = new Image(resource, "Kartu Pelajar");
                img.setWidthFull();
                img.getStyle().set("border-radius", "8px");
                dialog.add(img);
            } else {
                dialog.add(new Span("File kartu pelajar tidak ditemukan di server."));
            }
        } else {
            dialog.add(new Span("Siswa belum mengunggah kartu pelajar."));
        }

        Button btnClose = new Button("Tutup", e -> dialog.close());
        dialog.getFooter().add(btnClose);
        dialog.open();
    }
}