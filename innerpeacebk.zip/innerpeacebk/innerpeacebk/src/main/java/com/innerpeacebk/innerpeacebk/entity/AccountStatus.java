package com.innerpeacebk.innerpeacebk.entity;

public enum AccountStatus {
    PENDING,  
    APPROVED,  
    REJECTED   
}