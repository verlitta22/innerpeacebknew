package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.Konsultasi;
import com.innerpeacebk.innerpeacebk.repository.KonsultasiRepository;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.*;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.*;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.UUID;

@RolesAllowed("SISWA")
@Route(value = "siswa-ajukan-konsultasi")
public class AjukanKonsultasiView extends VerticalLayout {

    private VerticalLayout step1Layout, step2Layout, step3Layout, successLayout;
    private String selectedKategori = "";
    private final TextField judulField = new TextField("Topik Konsultasi *");
    private final TextArea deskripsiField = new TextArea("Detail Masalah *");
    private final RadioButtonGroup<String> metodeGroup = new RadioButtonGroup<>();
    private final RadioButtonGroup<String> waktuGroup = new RadioButtonGroup<>();
    private final TextArea catatanField = new TextArea("Catatan Tambahan");
    private final Checkbox persetujuanCheckbox = new Checkbox("Saya menyatakan data ini benar.");
    private String nisSiswa = "-";

    public AjukanKonsultasiView(UserRepository userRepository, KonsultasiRepository konsultasiRepository) {
        setAlignItems(Alignment.CENTER);
        setSizeFull();

        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof UserDetails ud) {
            userRepository.findByUsername(ud.getUsername()).ifPresent(u -> nisSiswa = u.getNisn());
        }

        VerticalLayout card = new VerticalLayout();
        card.setWidth("650px");
        card.add(new H2("Ajukan Konsultasi"));

        step1Layout = createStep1();
        step2Layout = createStep2();
        step3Layout = createStep3(konsultasiRepository);
        successLayout = createSuccess();

        step2Layout.setVisible(false); 
        step3Layout.setVisible(false); 
        successLayout.setVisible(false);
        
        card.add(step1Layout, step2Layout, step3Layout, successLayout);
        add(card);
    }

    private VerticalLayout createStep1() {
        VerticalLayout v = new VerticalLayout(new Span("Kategori Konsultasi *"));
        String[] kats = {"Akademik", "Mental", "Karier", "Pertemanan", "Lainnya"};
        HorizontalLayout hl = new HorizontalLayout();
        for (String k : kats) {
            Button b = new Button(k, e -> selectedKategori = k);
            hl.add(b);
        }
        
        judulField.setWidthFull();
        deskripsiField.setWidthFull();

        v.add(hl, judulField, deskripsiField, new Button("Selanjutnya", e -> {
            if (selectedKategori.isEmpty() || judulDataKosong(judulField.getValue()) || deskripsiField.getValue().isEmpty()) {
                Notification.show("Mohon lengkapi kategori, topik, dan detail masalah!", 3000, Notification.Position.MIDDLE);
                return;
            }
            step1Layout.setVisible(false); 
            step2Layout.setVisible(true);
        }));
        return v;
    }

    private boolean judulDataKosong(String val) {
        return val == null || val.trim().isEmpty();
    }

    private VerticalLayout createStep2() {
        VerticalLayout v = new VerticalLayout();
        metodeGroup.setLabel("Metode *");
        metodeGroup.setItems("Tatap Muka", "Online");
        waktuGroup.setLabel("Waktu *");
        waktuGroup.setItems("Pagi", "Siang");
        
        v.add(metodeGroup, waktuGroup, new Button("Selanjutnya", e -> {
            if (metodeGroup.getValue() == null || waktuGroup.getValue() == null) {
                Notification.show("Mohon pilih metode dan waktu konseling!", 3000, Notification.Position.MIDDLE);
                return;
            }
            step2Layout.setVisible(false); 
            step3Layout.setVisible(true);
        }));
        return v;
    }

    private VerticalLayout createStep3(KonsultasiRepository repo) {
        VerticalLayout v = new VerticalLayout();
        catatanField.setWidthFull();
        v.add(catatanField, persetujuanCheckbox, new Button("Kirim Pengajuan", e -> {
            if (!persetujuanCheckbox.getValue()) {
                Notification.show("Anda harus mencentang pernyataan kebenaran data!", 3000, Notification.Position.MIDDLE);
                return;
            }

            try {
                Konsultasi k = new Konsultasi();
                k.setKode("BK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
                k.setNis(nisSiswa);
                k.setKategori(selectedKategori);
                k.setTopik(judulField.getValue());
                k.setDetailMasalah(deskripsiField.getValue());
                k.setMetode(metodeGroup.getValue());
                k.setWaktu(waktuGroup.getValue());
                k.setCatatanGuruBk(catatanField.getValue());
                
                repo.save(k);
                
                step3Layout.setVisible(false); 
                successLayout.setVisible(true);
            } catch (Exception ex) {
                Notification.show("Gagal menyimpan: " + ex.getMessage(), 4000, Notification.Position.MIDDLE);
            }
        }));
        return v;
    }

    private VerticalLayout createSuccess() {
        return new VerticalLayout(new H2("Berhasil!"), new Span("Konsultasi terkirim."));
    }
}