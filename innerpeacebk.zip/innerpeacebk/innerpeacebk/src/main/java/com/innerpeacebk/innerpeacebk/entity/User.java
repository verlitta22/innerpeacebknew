package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nisn;
    private String namaLengkap;

    @Column(unique = true, nullable = false)
    private String username;

    private String password;
    private String kelas;
    private String kartuPelajarPath;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Enumerated(EnumType.STRING)
    private StatusAcc status;

    // --- ENUMS ---
    public enum Role {
        SISWA, GURU_BK
    }

    public enum StatusAcc {
        PENDING, APPROVED, REJECTED
    }

    // --- CONSTRUCTORS ---
    public User() {}

    // --- GETTERS & SETTERS ---
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNisn() {
        return nisn;
    }

    public void setNisn(String nisn) {
        this.nisn = nisn;
    }

    public String getNamaLengkap() {
        return namaLengkap;
    }

    public void setNamaLengkap(String namaLengkap) {
        this.namaLengkap = namaLengkap;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getKelas() {
        return kelas;
    }

    public void setKelas(String kelas) {
        this.kelas = kelas;
    }

    public String getKartuPelajarPath() {
        return kartuPelajarPath;
    }

    public void setKartuPelajarPath(String kartuPelajarPath) {
        this.kartuPelajarPath = kartuPelajarPath;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public StatusAcc getStatus() {
        return status;
    }

    public void setStatus(StatusAcc status) {
        this.status = status;
    }
}