package com.innerpeacebk.innerpeacebk.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "consultations")
public class Konsultasi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String kode;
    
    @Column(name = "nis")
    private String nis;

    private String kategori;
    private String topik;
    
    @Column(name = "detail_masalah", columnDefinition = "TEXT")
    private String detailMasalah;
    
    private String metode;
    private String waktu;
    private LocalDate tanggal;
    
    @Column(name = "jadwal_konseling")
    private String jadwalKonseling;
    
    @Column(name = "catatan_gurubk", columnDefinition = "TEXT")
    private String catatanGuruBk;
    
    private String status;
    
    @Column(name = "tanggal_pengajuan")
    private LocalDate tanggalPengajuan;

    public Konsultasi() {
        this.tanggalPengajuan = LocalDate.now();
        this.tanggal = LocalDate.now();
        this.status = "PENDING";
    }

    // GETTERS & SETTERS
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getKode() { return kode; }
    public void setKode(String kode) { this.kode = kode; }

    public String getNis() { return nis; }
    public void setNis(String nis) { this.nis = nis; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getTopik() { return topik; }
    public void setTopik(String topik) { this.topik = topik; }

    public String getDetailMasalah() { return detailMasalah; }
    public void setDetailMasalah(String detailMasalah) { this.detailMasalah = detailMasalah; }

    public String getMetode() { return metode; }
    public void setMetode(String metode) { this.metode = metode; }

    public String getWaktu() { return waktu; }
    public void setWaktu(String waktu) { this.waktu = waktu; }

    public LocalDate getTanggal() { return tanggal; }
    public void setTanggal(LocalDate tanggal) { this.tanggal = tanggal; }

    public String getJadwalKonseling() { return jadwalKonseling; }
    public void setJadwalKonseling(String jadwalKonseling) { this.jadwalKonseling = jadwalKonseling; }

    public String getCatatanGuruBk() { return catatanGuruBk; }
    public void setCatatanGuruBk(String catatanGuruBk) { this.catatanGuruBk = catatanGuruBk; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getTanggalPengajuan() { return tanggalPengajuan; }
    public void setTanggalPengajuan(LocalDate tanggalPengajuan) { this.tanggalPengajuan = tanggalPengajuan; }
}