package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

@RolesAllowed("GURU_BK")
@Route(value = "home", layout = GuruDashboardView.class)
public class GuruHomeView extends VerticalLayout {

    public GuruHomeView(LaporanKasusRepository laporanRepository) {
        setSizeFull();
        getStyle().set("padding", "35px").set("background-color", "#f8fafc");
        setSpacing(true);

        // Header Sambutan
        H1 title = new H1("Dashboard Guru BK");
        title.getStyle().set("color", "#0f172a").set("font-size", "24px").set("font-weight", "700").set("margin-bottom", "0px");

        LocalDate today = LocalDate.now();
        String formattedDate = today.getDayOfWeek().getDisplayName(TextStyle.FULL, new Locale("id", "ID")) + 
                ", " + today.getDayOfMonth() + " " + today.getMonth().getDisplayName(TextStyle.FULL, new Locale("id", "ID")) + 
                " " + today.getYear();
        
        Paragraph subtitle = new Paragraph(formattedDate + " · Selamat datang kembali, Bu Rina");
        subtitle.getStyle().set("color", "#64748b").set("font-size", "14px").set("margin-top", "4px");

        // Kartu Statistik Modern
        HorizontalLayout statsRow = new HorizontalLayout();
        statsRow.setWidthFull();
        statsRow.getStyle().set("gap", "20px");
        statsRow.setPadding(false);

        long totalLaporan = laporanRepository.count();

        statsRow.add(
            createStatCard("4", "Akun Verifikasi", VaadinIcon.USER, "#dbeafe", "#1d4ed8"),
            createStatCard(String.valueOf(totalLaporan), "Total Laporan Kasus", VaadinIcon.WARNING, "#fef3c7", "#d97706"),
            createStatCard("5", "Konsultasi Hari Ini", VaadinIcon.CHAT, "#d1fae5", "#059669"),
            createStatCard("3", "Jadwal Konseling", VaadinIcon.CALENDAR, "#ede9fe", "#7c3aed")
        );

        add(title, subtitle, statsRow);
    }

    private VerticalLayout createStatCard(String value, String label, VaadinIcon icon, String bgColor, String iconColor) {
        VerticalLayout card = new VerticalLayout();
        card.setWidth("240px");
        card.getStyle()
            .set("background", "#ffffff")
            .set("border-radius", "16px")
            .set("padding", "24px")
            .set("border", "1px solid #e2e8f0")
            .set("box-shadow", "0 1px 3px 0 rgba(0, 0, 0, 0.05)");
        card.setSpacing(false);
        card.setPadding(false);

        HorizontalLayout topRow = new HorizontalLayout();
        topRow.setWidthFull();
        topRow.setJustifyContentMode(JustifyContentMode.BETWEEN);
        topRow.setAlignItems(Alignment.CENTER);

        Span valSpan = new Span(value);
        valSpan.getStyle().set("font-size", "28px").set("font-weight", "700").set("color", "#0f172a");

        com.vaadin.flow.component.html.Div iconWrapper = new com.vaadin.flow.component.html.Div(icon.create());
        iconWrapper.getStyle()
            .set("background-color", bgColor)
            .set("color", iconColor)
            .set("width", "42px")
            .set("height", "42px")
            .set("border-radius", "12px")
            .set("display", "flex")
            .set("align-items", "center")
            .set("justify-content", "center");
        iconWrapper.getComponentAt(0).getElement().getStyle().set("width", "20px").set("height", "20px");

        topRow.add(valSpan, iconWrapper);

        Span lblSpan = new Span(label);
        lblSpan.getStyle().set("color", "#64748b").set("font-size", "13px").set("font-weight", "500").set("margin-top", "12px");

        card.add(topRow, lblSpan);
        return card;
    }
}