package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.entity.StatusKasus;
import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.*;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.Route;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

@RolesAllowed("GURU_BK")
@Route(value = "laporan/detail", layout = GuruDashboardView.class)
public class DetailLaporanView extends VerticalLayout implements HasUrlParameter<Long> {

    private final LaporanKasusRepository repository;
    private LaporanKasus currentLaporan;

    private final Span statusBadge = new Span();
    private final H2 kodeHeader = new H2();
    private final Span infoPengajuan = new Span();
    
    private final Span namaPelapor = new Span();
    private final Span lokasiVal = new Span();
    private final Span tanggalVal = new Span();
    
    private final Paragraph deskripsiText = new Paragraph();
    private final TextArea catatanField = new TextArea();

    @Autowired
    public DetailLaporanView(LaporanKasusRepository repository) {
        this.repository = repository;
        setSizeFull();
        setPadding(true);
        setSpacing(true);
        getStyle().set("background-color", "#f9fafb");

        buildViewLayout();
    }

    private void buildViewLayout() {
        Button backBtn = new Button(VaadinIcon.ARROW_LEFT.create(), e -> getUI().ifPresent(ui -> ui.navigate("laporan")));
        backBtn.addThemeVariants(ButtonVariant.LUMO_TERTIARY);

        HorizontalLayout topBar = new HorizontalLayout(backBtn, kodeHeader, statusBadge);
        topBar.setAlignItems(Alignment.CENTER);

        VerticalLayout leftContainer = new VerticalLayout();
        leftContainer.setWidth("65%");
        leftContainer.setSpacing(true);

        Div pelaporCard = createCard("Data Pelapor");
        pelaporCard.add(namaPelapor, lokasiVal, tanggalVal);

        Div kronologiCard = createCard("Kronologi Kejadian");
        kronologiCard.add(deskripsiText);

        Div catatanCard = createCard("Catatan Guru BK");
        catatanField.setWidthFull();
        catatanField.setPlaceholder("Tuliskan catatan atau tindak lanjut penanganan kasus...");
        
        Button btnSelesai = new Button("Selesaikan", VaadinIcon.CHECK.create(), e -> updateStatusAndSave(StatusKasus.SELESAI));
        btnSelesai.addThemeVariants(ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_SUCCESS);

        Button btnTolak = new Button("Tolak Laporan", VaadinIcon.CLOSE.create(), e -> updateStatusAndSave(StatusKasus.DITOLAK));
        btnTolak.addThemeVariants(ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_PRIMARY);

        HorizontalLayout actionButtons = new HorizontalLayout(btnSelesai, btnTolak);
        catatanCard.add(catatanField, actionButtons);

        leftContainer.add(pelaporCard, kronologiCard, catatanCard);

        VerticalLayout rightContainer = new VerticalLayout();
        rightContainer.setWidth("35%");
        
        Div timelineCard = createCard("Timeline Status");
        timelineCard.add(new Span("• Laporan Diterima\n• Sedang Diverifikasi\n• Ditangani Guru BK"));

        Div penanggungJawabCard = createCard("Penanganan");
        penanggungJawabCard.add(new Span("Ditangani oleh Guru BK yang bertugas"));

        rightContainer.add(timelineCard, penanggungJawabCard);

        HorizontalLayout mainContent = new HorizontalLayout(leftContainer, rightContainer);
        mainContent.setWidthFull();

        add(topBar, infoPengajuan, mainContent);
    }

    private Div createCard(String title) {
        Div card = new Div();
        card.getStyle().set("background", "white");
        card.getStyle().set("padding", "20px");
        card.getStyle().set("border-radius", "12px");
        card.getStyle().set("box-shadow", "0 1px 3px rgba(0,0,0,0.1)");
        card.getStyle().set("margin-bottom", "15px");
        
        H4 cardTitle = new H4(title);
        cardTitle.getStyle().set("margin-top", "0");
        card.add(cardTitle);
        return card;
    }

    @Override
    public void setParameter(BeforeEvent event, Long laporanId) {
        Optional<LaporanKasus> optionalLaporan = repository.findById(laporanId);
        if (optionalLaporan.isPresent()) {
            currentLaporan = optionalLaporan.get();
            populateData();
        } else {
            Notification.show("Data laporan tidak ditemukan!", 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_ERROR);
            event.forwardTo("laporan");
        }
    }

    private void populateData() {
        if (currentLaporan == null) return;

        kodeHeader.setText("LPR-2025-" + String.format("%03d", currentLaporan.getId()));
        statusBadge.setText(currentLaporan.getStatus().name());
        infoPengajuan.setText("Dilaporkan pada: " + currentLaporan.getTanggalDibuat());

        // Identitas pelapor langsung ditampilkan secara terbuka tanpa anonim
        String pelaporName = currentLaporan.getPelapor() != null ? currentLaporan.getPelapor().getUsername() : "N/A";
        namaPelapor.setText("Pelapor: " + pelaporName);

        lokasiVal.setText("Lokasi Kejadian: " + (currentLaporan.getLokasi() != null ? currentLaporan.getLokasi() : "-"));
        tanggalVal.setText("Tanggal Kejadian: " + (currentLaporan.getTanggalKejadian() != null ? currentLaporan.getTanggalKejadian() : "-"));
        
        deskripsiText.setText(currentLaporan.getDeskripsi() != null ? currentLaporan.getDeskripsi() : "-");
        catatanField.setValue(currentLaporan.getCatatanGuruBK() != null ? currentLaporan.getCatatanGuruBK() : "");
    }

    private void updateStatusAndSave(StatusKasus newStatus) {
        if (currentLaporan != null) {
            currentLaporan.setStatus(newStatus);
            currentLaporan.setCatatanGuruBK(catatanField.getValue());
            
            repository.save(currentLaporan);

            Notification.show("Status laporan berhasil diperbarui menjadi " + newStatus, 3000, Notification.Position.TOP_CENTER)
                        .addThemeVariants(NotificationVariant.LUMO_SUCCESS);
            
            getUI().ifPresent(ui -> ui.navigate("laporan"));
        }
    }
}