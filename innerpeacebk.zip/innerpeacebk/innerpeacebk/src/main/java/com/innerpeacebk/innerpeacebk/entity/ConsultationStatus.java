package com.innerpeacebk.innerpeacebk.entity;

public enum ConsultationStatus {
    MENUNGGU,    // Baru diajukan siswa
    DIJADWALKAN, // Guru BK sudah menentukan jadwal
    SELESAI,     // Sesi konseling selesai
    DITOLAK      // Berkas/pengajuan ditolak
}