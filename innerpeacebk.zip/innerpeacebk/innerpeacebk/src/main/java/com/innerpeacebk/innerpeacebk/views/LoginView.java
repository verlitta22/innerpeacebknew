package com.innerpeacebk.innerpeacebk.views;

import com.innerpeacebk.innerpeacebk.entity.User;
import com.innerpeacebk.innerpeacebk.entity.User.Role;
import com.innerpeacebk.innerpeacebk.entity.User.StatusAcc;
import com.innerpeacebk.innerpeacebk.repository.UserRepository;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;
import com.vaadin.flow.server.VaadinServletRequest;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;

import java.util.Collections;
import java.util.Optional;

@Route("login")
@PageTitle("Masuk ke Sistem - InnerPeaceBK")
@AnonymousAllowed
public class LoginView extends VerticalLayout {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    private final TextField usernameOrNisnField = new TextField("Username / NISN");
    private final PasswordField passwordField = new PasswordField("Password");
    private final Checkbox rememberMeCheckbox = new Checkbox("Ingat Saya");
    private final Button loginButton = new Button("Masuk");

    // Toggle Role (Siswa / Guru BK)
    private boolean isSiswaRoleSelected = true;
    private final Button btnSiswa = new Button("Siswa");
    private final Button btnGuru = new Button("Guru BK");

    public LoginView(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

        setSizeFull();
        setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        setAlignItems(FlexComponent.Alignment.CENTER);
        getStyle()
                .set("background-color", "#ffffff")
                .set("padding", "20px");

        add(createFormContainer());
    }

    private Div createFormContainer() {
        Div container = new Div();
        container.setWidth("100%");
        container.setMaxWidth("420px");

        VerticalLayout content = new VerticalLayout();
        content.setPadding(false);
        content.setSpacing(false);
        content.setAlignItems(FlexComponent.Alignment.STRETCH);

        // 1. Link Kembali ke Beranda
        RouterLink backLink = new RouterLink("", LandingView.class);
        HorizontalLayout backLayout = new HorizontalLayout();
        backLayout.setAlignItems(FlexComponent.Alignment.CENTER);
        backLayout.setSpacing(false);
        backLayout.getStyle().set("margin-bottom", "32px").set("cursor", "pointer");

        Icon backIcon = VaadinIcon.ARROW_LEFT.create();
        backIcon.getStyle()
                .set("width", "16px")
                .set("height", "16px")
                .set("color", "#64748b")
                .set("margin-right", "8px");

        Span backText = new Span("Kembali ke Beranda");
        backText.getStyle()
                .set("color", "#64748b")
                .set("font-size", "14px")
                .set("font-weight", "500");

        backLayout.add(backIcon, backText);
        backLink.add(backLayout);

        // 2. Logo Brand
        HorizontalLayout logoLayout = new HorizontalLayout();
        logoLayout.setAlignItems(FlexComponent.Alignment.CENTER);
        logoLayout.getStyle().set("margin-bottom", "24px");

        Icon logoIcon = VaadinIcon.HEART.create();
        logoIcon.getStyle().set("color", "#2563eb").set("width", "20px").set("height", "20px");
        
        Span logoText = new Span("InnerPeaceBK");
        logoText.getStyle()
                .set("color", "#2563eb")
                .set("font-weight", "700")
                .set("font-size", "15px")
                .set("margin-left", "6px");

        logoLayout.add(logoIcon, logoText);

        // 3. Judul & Subjudul
        H2 title = new H2("Masuk ke Sistem");
        title.getStyle()
                .set("margin", "0 0 6px 0")
                .set("color", "#0f172a")
                .set("font-size", "28px")
                .set("font-weight", "800");

        Paragraph subtitle = new Paragraph("Silakan login dengan akun yang telah terdaftar.");
        subtitle.getStyle()
                .set("margin", "0 0 24px 0")
                .set("color", "#64748b")
                .set("font-size", "14px");

        // 4. Role Selector (Siswa / Guru BK Toggle)
        Span roleLabel = new Span("Login Sebagai");
        roleLabel.getStyle()
                .set("font-size", "13px")
                .set("font-weight", "600")
                .set("color", "#334155")
                .set("margin-bottom", "8px")
                .set("display", "block");

        HorizontalLayout roleToggleGroup = createRoleToggleGroup();
        roleToggleGroup.getStyle().set("margin-bottom", "20px");

        // 5. Input Username / NISN
        usernameOrNisnField.setPlaceholder("Masukkan NISN atau username");
        usernameOrNisnField.setPrefixComponent(VaadinIcon.USER.create());
        usernameOrNisnField.setRequired(true);
        usernameOrNisnField.setWidthFull();
        usernameOrNisnField.getStyle().set("margin-bottom", "16px");

        // 6. Input Password
        passwordField.setPlaceholder("Masukkan password");
        passwordField.setPrefixComponent(VaadinIcon.LOCK.create());
        passwordField.setRequired(true);
        passwordField.setWidthFull();
        passwordField.getStyle().set("margin-bottom", "16px");

        // 7. Checkbox Ingat Saya
        rememberMeCheckbox.getStyle()
                .set("color", "#475569")
                .set("font-size", "14px")
                .set("margin-bottom", "24px");

        // 8. Tombol Masuk
        loginButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        loginButton.setWidthFull();
        loginButton.getStyle()
                .set("background-color", "#1d4ed8")
                .set("height", "48px")
                .set("border-radius", "10px")
                .set("font-size", "16px")
                .set("font-weight", "700")
                .set("cursor", "pointer")
                .set("box-shadow", "0 4px 12px rgba(37, 99, 235, 0.25)")
                .set("margin-bottom", "32px");

        loginButton.addClickListener(e -> handleLogin());
        passwordField.addKeyDownListener(Key.ENTER, e -> handleLogin());

        // 9. Footer Link (Daftar Sekarang)
        HorizontalLayout registerFooter = new HorizontalLayout();
        registerFooter.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
        registerFooter.setWidthFull();
        registerFooter.setSpacing(false);

        Span noAccountText = new Span("Belum punya akun? ");
        noAccountText.getStyle().set("color", "#64748b").set("font-size", "14px");

        RouterLink registerLink = new RouterLink("Daftar sekarang", RegisterView.class);
        registerLink.getStyle()
                .set("color", "#1d4ed8")
                .set("font-weight", "700")
                .set("font-size", "14px")
                .set("text-decoration", "none")
                .set("margin-left", "4px");

        registerFooter.add(noAccountText, registerLink);

        // Susun elemen ke dalam container
        content.add(
                backLink,
                logoLayout,
                title,
                subtitle,
                roleLabel,
                roleToggleGroup,
                usernameOrNisnField,
                passwordField,
                rememberMeCheckbox,
                loginButton,
                registerFooter
        );

        container.add(content);
        return container;
    }

    private HorizontalLayout createRoleToggleGroup() {
        HorizontalLayout toggleLayout = new HorizontalLayout();
        toggleLayout.setWidthFull();
        toggleLayout.getStyle()
                .set("background-color", "#f1f5f9")
                .set("border-radius", "12px")
                .set("padding", "4px")
                .set("box-sizing", "border-box");

        btnSiswa.setWidth("50%");
        btnGuru.setWidth("50%");

        btnSiswa.addClickListener(e -> updateRoleToggle(true));
        btnGuru.addClickListener(e -> updateRoleToggle(false));

        toggleLayout.add(btnSiswa, btnGuru);
        updateRoleToggle(true); // Default terpilih Siswa

        return toggleLayout;
    }

    private void updateRoleToggle(boolean selectSiswa) {
        this.isSiswaRoleSelected = selectSiswa;

        if (selectSiswa) {
            // Style Siswa Active
            btnSiswa.getStyle()
                    .set("background-color", "#ffffff")
                    .set("color", "#1d4ed8")
                    .set("font-weight", "700")
                    .set("border-radius", "8px")
                    .set("box-shadow", "0 2px 6px rgba(0,0,0,0.06)")
                    .set("border", "none");

            // Style Guru BK Inactive
            btnGuru.getStyle()
                    .set("background-color", "transparent")
                    .set("color", "#64748b")
                    .set("font-weight", "600")
                    .set("border-radius", "8px")
                    .set("box-shadow", "none")
                    .set("border", "none");
        } else {
            // Style Guru BK Active
            btnGuru.getStyle()
                    .set("background-color", "#ffffff")
                    .set("color", "#1d4ed8")
                    .set("font-weight", "700")
                    .set("border-radius", "8px")
                    .set("box-shadow", "0 2px 6px rgba(0,0,0,0.06)")
                    .set("border", "none");

            // Style Siswa Inactive
            btnSiswa.getStyle()
                    .set("background-color", "transparent")
                    .set("color", "#64748b")
                    .set("font-weight", "600")
                    .set("border-radius", "8px")
                    .set("box-shadow", "none")
                    .set("border", "none");
        }
    }

    private void handleLogin() {
        String inputUser = usernameOrNisnField.getValue().trim();
        String password = passwordField.getValue();

        if (inputUser.isEmpty() || password.isEmpty()) {
            showNotification("Username/NISN dan Password tidak boleh kosong!", NotificationVariant.LUMO_ERROR);
            return;
        }

        // Cari user berdasarkan Username atau NISN
        Optional<User> userOptional = userRepository.findByUsername(inputUser);
        if (userOptional.isEmpty()) {
            userOptional = userRepository.findByNisn(inputUser);
        }

        if (userOptional.isPresent()) {
            User user = userOptional.get();

            // 1. Validasi Pilihan Toggle Role (Siswa vs Guru BK)
            boolean isUserGuru = (user.getRole() == Role.GURU_BK);
            if (isSiswaRoleSelected && isUserGuru) {
                showNotification("Akun ini terdaftar sebagai Guru BK, silakan pilih tab 'Guru BK'!", NotificationVariant.LUMO_ERROR);
                return;
            }
            if (!isSiswaRoleSelected && !isUserGuru) {
                showNotification("Akun ini terdaftar sebagai Siswa, silakan pilih tab 'Siswa'!", NotificationVariant.LUMO_ERROR);
                return;
            }

            // 2. Cek Status Verifikasi
            if (user.getStatus() != null && user.getStatus() != StatusAcc.APPROVED) {
                showNotification("Akun Anda belum disetujui / diverifikasi oleh Admin!", NotificationVariant.LUMO_ERROR);
                return;
            }

            // 3. Cek Password
            if (passwordEncoder.matches(password, user.getPassword())) {

                // --- SET AUTHENTICATION DI SPRING SECURITY CONTEXT & HTTP SESSION ---
                String roleName = "ROLE_" + user.getRole().name();
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                        user.getUsername(),
                        null,
                        Collections.singletonList(new SimpleGrantedAuthority(roleName))
                );

                SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
                securityContext.setAuthentication(authToken);
                SecurityContextHolder.setContext(securityContext);

                // Simpan SecurityContext ke HTTP Session
                VaadinServletRequest.getCurrent().getHttpServletRequest().getSession()
                        .setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);

                // Simpan User di Vaadin Session
                VaadinSession.getCurrent().setAttribute(User.class, user);

                showNotification("Selamat datang kembali, " + user.getNamaLengkap() + "!", NotificationVariant.LUMO_SUCCESS);

                // 4. Navigasi Berdasarkan Role
                if (user.getRole() == Role.GURU_BK) {
                    UI.getCurrent().navigate(GuruDashboardView.class);
                } else {
                    UI.getCurrent().navigate(SiswaDashboardView.class);
                }
            } else {
                showNotification("Password yang Anda masukkan salah!", NotificationVariant.LUMO_ERROR);
            }
        } else {
            showNotification("Username / NISN tidak ditemukan!", NotificationVariant.LUMO_ERROR);
        }
    }

    private void showNotification(String message, NotificationVariant variant) {
        Notification notification = Notification.show(message, 3000, Notification.Position.TOP_CENTER);
        notification.addThemeVariants(variant);
    }
}