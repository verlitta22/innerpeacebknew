package com.innerpeacebk.innerpeacebk.repository;

import com.innerpeacebk.innerpeacebk.entity.SesiKonseling;
import com.innerpeacebk.innerpeacebk.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SesiKonselingRepository extends JpaRepository<SesiKonseling, Long> {
    long countBySiswa(User siswa);
    long countBySiswaAndStatus(User siswa, String status);
    
    List<SesiKonseling> findBySiswa(User siswa);
    List<SesiKonseling> findByGuruBk(User guruBk);
}