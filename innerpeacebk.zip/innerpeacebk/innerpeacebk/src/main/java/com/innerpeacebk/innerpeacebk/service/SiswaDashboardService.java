package com.innerpeacebk.innerpeacebk.service;

import com.innerpeacebk.innerpeacebk.entity.Konsultasi;
import com.innerpeacebk.innerpeacebk.entity.LaporanKasus;
import com.innerpeacebk.innerpeacebk.repository.KonsultasiRepository;
import com.innerpeacebk.innerpeacebk.repository.LaporanKasusRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SiswaDashboardService {

    @Autowired
    private KonsultasiRepository konsultasiRepository;

    @Autowired
    private LaporanKasusRepository laporanKasusRepository;

    // Menghitung total konsultasi milik siswa berdasarkan NIS
    public long getTotalKonsultasi(String nis) {
        return konsultasiRepository.countByNis(nis);
    }

    // Menghitung jumlah konsultasi berdasarkan NIS dan status
    public long getKonsultasiByStatus(String nis, String status) {
        return konsultasiRepository.countByNisAndStatus(nis, status);
    }

    // Mengambil daftar riwayat konsultasi terbaru berdasarkan NIS (dibatasi 3 teratas untuk dashboard)
    public List<Konsultasi> getRiwayatKonsultasiTerbaru(String nis) {
        List<Konsultasi> list = konsultasiRepository.findByNisOrderByIdDesc(nis);
        // Batasi maksimal 3 data untuk tampilan dashboard
        if (list.size() > 3) {
            return list.subList(0, 3);
        }
        return list;
    }

    // Mengambil daftar laporan kasus berdasarkan ID user pelapor
    public List<LaporanKasus> getLaporanKasusSiswa(Long userId) {
        return laporanKasusRepository.findByPelaporId(userId);
    }
}