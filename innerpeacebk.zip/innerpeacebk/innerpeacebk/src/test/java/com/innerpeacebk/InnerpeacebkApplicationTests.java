package com.innerpeacebk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnerpeacebkApplicationTests {

	@Test
	void contextLoads() {
	}

}
